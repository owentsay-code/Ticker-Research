# Rubric readiness — no predicted grade

| Criterion | Weight | Prepared evidence | Material remaining concern |
| --- | --- | --- | --- |
| Problem definition and decision usefulness | 45 | Edition B mandate/horizon; committee action and reversal conditions; A-to-B table | Original checkpoint receipt; student endorsement of added horizon/triggers |
| Data integrity and traceability | 45 | Evidence ledger, source periods, normalization catalog, account mappings, archived history | Full unusual-item/tax/claim review; lagged shares and annual peers explicitly qualified |
| Financial soundness and judgment | 60 | Linked statements, FCFF DCF/bridge, causal range, reverse DCF, EV and equity peer multiples | WACC remains a hurdle judgment; terminal economics and condensed accounting need defense |
| Technical execution and usability | 45 | Bounded driver panel, reset, loud failure, offline standard-library engine, readable output | Student's independent startup/access check; no repository-link rule supplied |
| Validation, sensitivity and reproducibility | 75 | 32 tests, source checks, Decimal answer, cold-run log, ranking reversal, AI-output disposition | Human AI-off locked precommit, official training answer comparison and recorded cold run |
| Professional communication | 30 | Memo, Edition B, README, manifest and distinct recording guides | Three actual videos, corrected transcripts and official naming/access checks |

The largest unresolved grading risk is the 75-point validation category, especially the human AI-off requirement. Videos alone cannot repair that evidence gap. Polishing the interface further is lower priority than supplying the missing authentic records and demonstrating judgment.
