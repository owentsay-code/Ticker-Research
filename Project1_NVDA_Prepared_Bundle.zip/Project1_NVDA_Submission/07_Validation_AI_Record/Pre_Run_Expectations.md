# AI-assisted test expectations — not the human AI-off record

Written during package preparation on October 19, 2026 before the new validation suite is executed. This is an AI-authored technical test specification. It must not replace the student's required AI-off prediction.

- Raising WACC from 10% to 11%, keeping everything else fixed, should reduce value/share. Year 5 EBIT and FCFF should not change. This should strengthen the existing watch/defer conclusion, not independently justify initiation.
- Raising terminal growth from 3.5% to 4.5%, keeping everything else fixed, should increase value/share. Explicit-period EBIT and FCFF should not change. A higher result without supporting evidence should not change the base decision.
- WACC equal to terminal growth must withhold valuation; an 85% EBIT margin at 70–74% gross margin must fail the nonnegative-R&D feasibility check. A one-billion-dollar corruption of opening equity must fail opening reconciliation. These failures must not produce a usable recommendation.
- Resetting all controls must reproduce the saved base exactly. No future accumulated cash may be added to the opening enterprise-equity bridge.
- Narrowing the growth range from ±5pp to ±1pp while retaining margin ±5pp should reduce its measured importance; the actual ranking must be checked for EBIT, FCFF and value separately.

The original September scenario and results were already visible before this work. The checks here are prospective automated regression specifications, not claims of an unseen student experiment.
