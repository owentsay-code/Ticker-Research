# Human-authored AI-off locked changed-input record — BLANK

This blank structure contains no prediction. It is not a completed validation record. Locate the genuine earlier record first; if remediation is needed, follow the instructor's rules for a new prospective experiment. An already-seen result cannot honestly be treated as unseen. Do not backdate or use AI to author the prediction.

## Before execution — completed by student with AI off

Student name:

Actual creation timestamp and timezone:

Company / valuation date / model version and file hash:

Single independent input and units:

Old value/path and forecast years:

New value/path and forecast years:

All other independent inputs held fixed:

My predicted direction for operating profit:

My predicted direction for FCFF:

My predicted direction for value:

My reasoning and expected decision effect:

Evidence of precommit before the run (actual commit ID, dated submission receipt, or course-approved timestamp artifact):

Human challenger, if any, and actual question:

## After execution — preserve the original prediction above

Actual run timestamp / version:

Actual base and changed results / units:

Predicted versus actual direction:

Actual decision effect:

Failure diagnosis or reason for no change:

Links to outputs and checks:

Any AI assistance after the locked human prediction:

Only attest to steps that actually occurred. A newly generated local file hash alone does not prove a historical precommit.
