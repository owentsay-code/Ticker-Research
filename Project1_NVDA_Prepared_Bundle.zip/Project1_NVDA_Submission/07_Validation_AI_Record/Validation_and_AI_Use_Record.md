# Validation and AI-use record

Prepared October 19, 2026. This record is frozen by the package manifest at generation time. Re-run the manifest after legitimate additions; preserve old evidence rather than changing its history. No course receipt or video has been fabricated.

## Completed technical evidence

- 32 automated test assertions passed in Automated_Validation.json, including source-to-opening mapping, historical cash reconciliation, independent FCFF calculations, statement checks, bridge identities, WACC/g direction, invalid controls, corrupt opening equity, terminal denominator rejection, negative-R&D failure, reset, causal ordering, range-dependent rankings, reverse re-pricing, and peer definitions.
- Synthetic training value $27.497370398196844… independently rebuilt with Decimal arithmetic versus the original training engine. Direct comparison against the course's published training answer table remains pending.
- Fresh environment: Cold_Run_Log.json records creation of a new temporary virtual environment without pip, tests, complete export, peer calculations and exact match to the packaged results. This is a logged software run, not a student's video.
- Browser UI verified in Chrome: base $209.28 → growth shift +2pp $224.81 → incoherent 85% EBIT margin FAIL with valuation withheld → restored $209.28. Five-year tables and sensitivity results rendered. The live server uses localhost only.
- Pre_Run_Expectations.md was written before the new suite, and its SHA-256 is captured in the test log. It is explicitly AI-authored, not the required human AI-off prediction.

## Highest-risk claims and tests

Economic risk: terminal value dominates EV and depends on margins, reinvestment, WACC and g. Tests cover monotonicity and the undefined WACC=g boundary; causal cases and range experiments disclose uncertainty. These tests do not establish a true terminal margin or fair value.

Accounting risk: a balanced model can conceal impossible expenses. The 85% EBIT test forces negative R&D despite arithmetic articulation; the workbench shows FAIL and withholds valuation. A separate opening-equity corruption test prevents a plugged historical balance sheet from silently passing.

Definition risk: primary documents were reopened to map quarterly diluted shares, cash/debt/securities and the company FCF definition. The model labels its own unlevered FCFF convention instead of equating it with provider FCF. Peer formulas use consistent annual definitions while explicitly qualifying stale shares and balance sheets.

## AI-use disclosure

Current assistance: Codex inventoried local files, preserved Edition A, read archived models/reports, reopened public sources, built the wrapper/interface, added cases/robustness checks and annual EV/revenue diagnostics, ran tests and a fresh environment, drafted Edition B/memo/guides, and assembled the package. The accounting model and earlier AI-assisted artifacts are preserved in the archive. This is substantive research/coding/writing assistance, not merely proofreading.

Student-owned tasks still required: endorse or revise the investment judgments; supply original receipt and actual human challenge identity; prove human AI-off prediction/precommit or complete approved remediation; deliver recorded defenses; correct transcripts against actual speech; check access and final submission receipt. Earlier session prompts and timing cannot be fully reconstructed from local files. No claim is made that all earlier work was human-authored or AI-off.

AI output disposition: QUALIFIED the saved $209.28 output after numerical replication and independent source mapping. ACCEPTED the need to test range dependence, now executed. REJECTED using accounting PASS or peer-median price alone as investment proof. Independent evidence: linked NVIDIA filings and earnings release, explicit share/FCF definitions, and reproducible arithmetic; see Evidence_Ledger.md. These are the assistant's current documented judgments, to be reviewed by the student, not invented prior student decisions.

## Required evidence not yet established

| Item | Honest status | Resolution |
| --- | --- | --- |
| Edition A checkpoint | Local original/hash found; Brightspace receipt missing | Supply original first-success receipt |
| Locked changed-input prediction | September text includes assistant-as-Partner; human AI-off authorship and precommit not established | Supply genuine evidence or follow instructor remediation |
| Course known answers | Synthetic arithmetic passes; published answer sheet not supplied | Attach/check starter answer sheet |
| Human fresh eyes | Partner challenge reported; challenger identity absent | Supply actual name/credit, if required |
| Prior peer policy | September artifact says no policy assigned | October prospective re-validation documented; do not backdate |
| Three videos and corrected transcripts | Not recorded | Student records; correct actual transcripts |
| Recorded cold run | Written clean run complete; student video missing | Record new clean run in Video 2 |
| Shared checklist, naming and duration | Not supplied; rubric only | Confirm official checklist |
| Final access/integrity receipt | Local package only; no upload | Verify links/downloads and save Brightspace receipt |

## Post-recording freeze

After adding authentic media, transcripts, receipt and completed records, run `python3 freeze_manifest.py` from the package root, then `python3 package_zip.py`. Neither command uploads anything. Keep a copy of the version actually submitted and its receipt. Do not describe this preparation ZIP as a final complete submission while the evidence above is missing.
