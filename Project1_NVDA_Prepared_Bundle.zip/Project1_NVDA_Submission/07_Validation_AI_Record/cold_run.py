"""Create a genuinely fresh standard-library-only environment and preserve its execution log."""
from pathlib import Path
import tempfile, shutil, subprocess, sys, json, datetime, venv, hashlib
root=Path(__file__).resolve().parents[1]
source=root/'03_Repository_Visible_Output/app'
clean=Path(tempfile.mkdtemp(prefix='nvda_project1_cold_'))
app=clean/'03_Repository_Visible_Output/app';app.mkdir(parents=True)
for f in source.iterdir():
 if f.is_file(): (app/f.name).write_bytes(f.read_bytes())
records=clean/'07_Validation_AI_Record';records.mkdir()
(records/'Pre_Run_Expectations.md').write_bytes((root/'07_Validation_AI_Record/Pre_Run_Expectations.md').read_bytes())
venv.EnvBuilder(with_pip=False).create(clean/'venv')
py=clean/'venv/bin/python'
log={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fresh_directory':str(clean),'python':sys.version,'third_party_packages':'none; venv without pip','source_hashes':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.iterdir() if f.is_file()},'commands':[]}
for cmd in [[str(py),'-B','validate.py'],[str(py),'-B','workbench.py','--export'],[str(py),'-B','peer_comparison.py']]:
 r=subprocess.run(cmd,cwd=app,text=True,capture_output=True,timeout=60)
 log['commands'].append({'argv':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 if r.returncode:break
log['all_passed']=all(r['returncode']==0 for r in log['commands']) and len(log['commands'])==3
original=json.loads((root/'03_Repository_Visible_Output/Project1_NVDA_Results.json').read_text())
reproduced=json.loads((app.parent/'Project1_NVDA_Results.json').read_text())
log['exact_export_match']=original==reproduced
log['ui_scope']='Browser controls were separately exercised against the packaged app: base, growth +2pp, infeasible margin, reset. This clean-environment log covers engine/exports/validation; it is not a video.'
log['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(root/'07_Validation_AI_Record/Cold_Run_Log.json').write_text(json.dumps(log,indent=2)+'\n')
print('Clean environment:',clean,'PASS:',log['all_passed'],'Exact export:',log['exact_export_match'])
raise SystemExit(not(log['all_passed'] and log['exact_export_match']))
