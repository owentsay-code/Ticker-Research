# Video 1 — Research evolution

This is an AI-assisted preparation guide, not a transcript. Verify the course's duration and naming rules; no exact limit was supplied. Keep this recording distinct from code defense and committee defense.

1. Show the unchanged Edition A and its actual Brightspace receipt. Explain what you believed before valuation-specific AI assistance. Do not claim an AI-off boundary without the evidence.
2. Explain the change from provisional INITIATE based on company screening to WATCH/DEFER based on valuation. Screening admitted NVIDIA to research; it did not establish price attractiveness.
3. Show Edition B's change table and one source transformation: FY26 + current H1 - prior H1 sales = $302.970bn. Explain why fiscal years, reporting dates and the September 8 valuation date differ.
4. Show one consequential AI output you qualified: the $209.28 base is reproducible, but it depends on an assumed 10% WACC, a 58% terminal margin and a share proxy. Show the filing source and definition check rather than saying another AI agreed.
5. Explain the fresh-eyes challenge about an AI spending bubble. Credit the actual human challenger by name if known; distinguish this from the assistant acting as Partner in the archived prediction discussion.
6. End with what changed your decision and what evidence could reverse it. Identify the remaining judgments you own.

Suggested screen order: Edition A → receipt → Edition B change table → evidence ledger → assumption challenge record → committee decision.

After recording, save the actual video under the official course filename (provisional: Project1_NVDA_Video1.mp4). Create a transcript from the recording, correct it against the audio and save Project1_NVDA_Video1_Transcript.txt. Include meaningful timestamps and on-screen actions. Do not submit this guide as a corrected transcript.
