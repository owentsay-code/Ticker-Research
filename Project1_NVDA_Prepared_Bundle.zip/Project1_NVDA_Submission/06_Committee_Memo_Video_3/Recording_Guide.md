# Video 3 — Live product demo and committee defense

This is a rehearsal guide, not a transcript. The assignment requires the live product opening in roughly the first minute. The total official video duration was not provided.

## Required opening: about one minute

- 0–10 seconds: have the working browser app on screen, restored to base. State: “This tool lets an analyst test NVIDIA's operating assumptions while keeping the accounting and checks fixed. My historical September 8 recommendation is watch/defer.”
- 10–25 seconds: move Growth path shift from 0 to +2 percentage points. Read $224.81/share versus the $209.28 base; Year 5 EBIT $545.11bn and FCFF $415.38bn. Higher sales compound; taxes and reinvestment absorb part of incremental profit.
- 25–35 seconds: click Restore base. Show the exact $209.28 return. Explain that a favorable slider move supplies no new evidence and does not change your base recommendation.
- 35–50 seconds: click Test incoherent 85% EBIT margin. Show the red failure and withheld valuation. Explain that gross margins of 70–74% cannot support 85% EBIT after nonnegative operating expenses; the engine finds negative R&D. This is an explicitly labeled diagnostic input outside the normal scenario panel, not a valid forecast.
- 50–60 seconds: restore base again. Show PASS and the recovered value. Explain that checks reject incoherent assumptions but do not certify the remaining assumptions as likely.

## Defend the decision with the tool still visible

Explain the $125–$386 conditional causal-case range, the $209 base anchor, and the historical $225.73 quote. Distinguish the $164–$294 WACC/g-only envelope from the combined operating/risk cases. State that neither is a confidence interval or a full collapse stress.

Show the terminal share (78%) and explain why perpetual profitability and cost of capital deserve challenge. Show the sensitivity table: growth is the largest operating driver over the selected ranges; WACC and terminal growth also materially affect value. A smaller growth interval reverses its ranking versus margin.

Explain why the peer P/E result is much higher and why you did not average it with DCF. Mention annual denominators, business mix, earnings adjustments and the two-peer removal instability. The EV/revenue comparison is a qualified diagnostic.

End with action conditions: initiate only after conservative value and a margin of safety are supported; defer while uncertainty remains; do not initiate if demand/funding/pricing evidence invalidates the lower case. Name the next evidence you will review. Ratify the draft's monitoring thresholds in your own words before using them.

## Questions to rehearse

- Why is 10% WACC appropriate? It is the inherited hurdle assumption; the draft does not falsely claim a completed current CAPM estimate. Show 9–11% sensitivity and explain evidence needed to improve it.
- Why do high growth and stronger EBIT produce a smaller FCFF increase? Taxes, capex and incremental working capital consume cash.
- What if the AI bubble pops? Useful technology does not guarantee customer spending; current ±5pp cases are not a collapse case. Rebuild the operating assumptions if funding/demand breaks.
- Why not buy because peers look more expensive? Their multiple is not automatically transferable, and our range does not demonstrate conservative upside at the historical quote.

Provisional video name: Project1_NVDA_Video3.mp4. Generate and correct Project1_NVDA_Video3_Transcript.txt from what you actually say, including the demo actions. Keep the memo alongside the video. No finished recording or transcript is included yet.
