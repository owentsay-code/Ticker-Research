# NVIDIA: WATCH / DEFER

Prepared October 19, 2026 for student review and ownership. Historical valuation date: September 8, 2026. Intended user: buy-side portfolio manager and analyst committee; fund currently has no position. Decision horizon: initiation review over the next 12 months, supported by five rolling forecast years and a continuing value. Security: NASDAQ NVDA common stock; USD; 24.285bn quarterly diluted weighted-average shares used as a valuation-date proxy.

## Committee decision

Retain **WATCH / DEFER**. The conditional DCF scenario range is approximately **$125–$386/share**, with a **$209/share base anchor**, versus the historical September 8 close of **$225.73**. The base is 7.3% below that quote; the upper outcome requires several favorable conditions together. The range is a scenario envelope, not a probability interval or a claim that all outcomes are equally likely. Screening selected the company; it does not establish investment value. [Historical close](https://stockanalysis.com/stocks/nvda/history/).

| Scenario | Causal assumptions | Year 5 EBIT ($bn) | Year 5 FCFF ($bn) | Value/share |
| --- | --- | --- | --- | --- |
| Low | Growth -5pp; EBIT margin -5pp; WACC 11%; g 2.5% | 373.24 | 290.41 | $125.30 |
| Base | Saved growth/margins; WACC 10%; g 3.5% | 502.82 | 385.97 | $209.28 |
| High | Growth +5pp; EBIT margin +5pp; WACC 9%; g 4.5% | 666.74 | 506.73 | $386.04 |

The lower case links slower deployment to weaker growth and pricing, with a higher required return and lower mature growth. The upper case links faster adoption and durable pricing to stronger economics and lower perceived risk. These combined cases are new AI-assisted extensions of the saved assumptions and need the student's endorsement. They do not test a full AI-spending collapse; outcomes outside this range remain possible. A narrower $164–$294 range changes only WACC and terminal growth while preserving the operating base and should not be confused with the causal-case range.

## Why defer

The model has substantial long-run exposure: terminal value is 78.0% of enterprise value. Its 58% terminal operating margin and 10% WACC are assumptions, not independently established market facts. A reverse DCF requires approximately 26.26% constant annual revenue growth for five years to match $225.73, holding all other assumptions fixed. This is one conditional expectation, not the market's uniquely revealed forecast.

The equity bridge is explicit: EV $5,016.250bn + cash $22.443bn + marketable securities $76.926bn - debt $33.366bn = equity $5,082.253bn; divide by 24.285bn shares. Cash and securities are assumed available at carrying value without realization taxes; nonmarketable holdings are excluded. Operating leases remain within operating costs. Forecast cash is not added a second time. Source dates and mappings are in the evidence ledger.

## Methods disagree for economic reasons

The saved annual-GAAP peer P/E exercise produces $379–$935/share, with a $657 midpoint. AMD and Broadcom are qualified business comparisons, not interchangeable earnings streams. Growth, mix, acquisition amortization, tax effects and fiscal-year timing differ. The added annual EV/revenue comparison avoids EPS as its denominator but still ignores profitability differences and uses lagged capitalization proxies. It is a diagnostic, not a replacement target. Do not average those methods into an apparently precise fair value. No transaction multiple is used because a defensible control/synergy/time comparison has not been established.

## Conditions that change the action

- **Consider initiation:** price at least 20% below a newly reviewed conservative value, with the lower-case demand, margins and reinvestment supported by fresh evidence. Applied mechanically to today's draft lower case, that review threshold is about $100/share; it is an analyst-proposed margin-of-safety rule, not an automatic buy order. Alternatively, stronger independently supported operating evidence could raise conservative value. Re-run the full range first.
- **Continue defer:** the quote sits within the wide range but conservative downside and terminal uncertainty remain unresolved, or improved results come solely from moving sliders without new evidence.
- **Do not initiate:** customer funding failures, sustained demand contraction, export restrictions, or loss of pricing power invalidate even the conservative operating case; replace that case instead of stretching the current range.

At each earnings release, review revenue versus the declining growth path, operating margins versus the year-specific path, working-capital intensity, capital spending, and customer concentration/funding. Two consecutive quarters that imply growth below the lower path or operating margins more than 5pp below the base path trigger a rebuild; a single material financing or export event triggers immediate review. These are monitoring judgments, not company forecasts. The student should ratify the horizon and numerical triggers before recording.

## Decision limits and evidence

The model passes numerical reconciliation and failure tests; that does not prove the assumptions. Detailed share dilution, debt maturities, investment taxes, and operating working-capital account forecasts remain simplified. The cost of capital is a scenario hurdle, not a current CAPM estimate. Annual peers remain stale relative to the quote. The full primary-source review, assumptions, visible statements and validation are packaged separately. Course compliance also needs the original Edition A receipt, genuine human AI-off prediction evidence, published course benchmark comparison, three actual videos and corrected transcripts.

Sources: [NVIDIA FY2026 10-K](https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/nvda-20260125.htm); [Q2 FY2027 release](https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Announces-Financial-Results-for-Second-Quarter-Fiscal-2027/default.aspx); [AMD 2025 10-K](https://ir.amd.com/financial-information/sec-filings/content/0000002488-26-000018/amd-20251227.htm); [Broadcom FY2025 10-K](https://www.sec.gov/Archives/edgar/data/1730168/000173016825000121/avgo-20251102.htm). Primary documents were re-opened October 19, 2026; only pre-valuation-date information is used for the historical analysis.
