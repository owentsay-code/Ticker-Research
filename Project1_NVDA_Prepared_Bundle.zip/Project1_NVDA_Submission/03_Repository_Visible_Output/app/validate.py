"""Deterministic financial tests; prints machine-readable evidence, exits nonzero on failure."""
from copy import deepcopy
from decimal import Decimal, getcontext
from datetime import datetime, timezone
import hashlib, json, math
from pathlib import Path
from workbench import BASE, calculate, analyze, inputs_for
from nvidia_sensitivity import run_case
import training_dcf
from peer_comparison import results as peer_results

checks=[]
def check(name, condition, details=''):
    checks.append(dict(test=name,status='PASS' if condition else 'FAIL',details=details))
def close(a,b):return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-8)

b=calculate(); check('Saved base regression',close(b['outputs']['per_share'],209.27541148200564))
check('Base accounting',all(c['status']=='PASS' for c in b['checks']))
o=BASE['OPENING']
# Independently transcribed primary-source amounts, USD billions.
filing={'cash':22.443,'securities':34.143+42.783,'ar':63.059,'inventory':31.575,
 'prepaid':3.409,'ppe':14.285,'intangibles':2.998,
 'other_assets':5.390+21.125+12.159+51.157+15.746,
 'ap':15.059,'accrued':26.960,'debt':1.000+32.366,
 'other_liabilities':4.985+10.918,'equity':228.984,'revenue':215.938+177.837-90.805}
check('Opening source-to-model mapping',all(close(o[k],v) for k,v in filing.items()),'Q2 FY2027 release balance sheet; FY26 + H1 FY27 - H1 FY26 sales')
check('Six-month historical cash rollforward',close(10.605+74.421-35.124-27.459,22.443))
check('Shares definition',BASE['SHARES']==24.285,'Quarterly diluted weighted-average proxy, not period-end basic or six-month diluted')
check('Enterprise-equity bridge',close(b['valuation']['equity'],b['valuation']['ev']+22.443+34.143+42.783-33.366))
check('Per-share bridge',close(b['valuation']['equity']/24.285,b['outputs']['per_share']))
prev=o
for row in b['rows']:
    rev=prev['revenue']*(1+BASE['GROWTH'][row['year']-1])
    independent=rev*BASE['MARGINS'][row['year']-1]*(1-BASE['TAX'])+rev*(BASE['DA_RATIO']-BASE['CAPEX_RATIO'])-(rev-prev['revenue'])*BASE['WC_RATIO']
    check('Independent FCFF year '+str(row['year']),close(independent,row['fcff']))
    prev=row
check('WACC direction',calculate({'wacc':11})['outputs']['per_share']<b['outputs']['per_share']<calculate({'wacc':9})['outputs']['per_share'])
check('Terminal growth direction',calculate({'terminal':2.5})['outputs']['per_share']<b['outputs']['per_share']<calculate({'terminal':4.5})['outputs']['per_share'])
check('WACC leaves operating outputs unchanged',all(calculate({'wacc':11})['outputs'][k]==b['outputs'][k] for k in ('ebit','fcff')))
bad=deepcopy(BASE);bad['WACC']=bad['TERMINAL_GROWTH']
check('Reject singular terminal denominator',run_case(bad)['valuation'] is None)
bad=deepcopy(BASE);bad['MARGINS']=[.85]*5
stress=run_case(bad)
check('Highest-risk infeasible accounting inputs',stress['status']=='INVALID' and stress['valuation'] is None and any(c['status']=='FAIL' and c['check']=='rd nonnegative' for c in stress['checks']))
bad=deepcopy(BASE);bad['OPENING']['equity']+=1
check('Corrupted opening equity fails loudly',run_case(bad)['status']=='INVALID')
for params in ({'growth_shift':6},{'tax':float('nan')},{'unknown':1}):
    try:inputs_for(params); ok=False
    except ValueError:ok=True
    check('Reject invalid panel input '+str(params),ok)
a=analyze()
check('All causal cases valid',all(v['status']=='VALID' for v in a['cases'].values()))
check('Causal case ordering',a['cases']['Low']['outputs']['per_share']<b['outputs']['per_share']<a['cases']['High']['outputs']['per_share'])
for k in ('ebit','fcff','per_share'):
    check('Range-dependent ranking '+k,a['ranking'][0]['growth_spans'][k]>a['ranking'][0]['margin_spans'][k] and a['ranking'][1]['growth_spans'][k]<a['ranking'][1]['margin_spans'][k])
reverse=deepcopy(BASE);reverse['GROWTH']=[a['reverse_growth']]*5
check('Reverse DCF reprices historical quote',close(run_case(reverse)['outputs']['per_share'],225.73))
check('Exact reset',calculate()==b)
peers=peer_results()
check('Peer identity and positive denominator policy',len({p['symbol'] for p in peers})==3 and all(p['eps']>0 and p['revenue']>0 for p in peers))
check('Peer P/E definition',all(close(p['pe']*p['eps'],p['price']) for p in peers))
check('Peer EV definition',all(close(p['ev_revenue']*p['revenue'],p['price']*p['shares']+p['debt']-p['cash']-p['securities']) for p in peers))
getcontext().prec=40
D=Decimal; cf=D(100); pv=D(0)
for t,g in enumerate(['.08','.06','.05','.04','.03'],1):
    cf*=1+D(g);pv+=cf/D('1.1')**t
answer=(pv+cf*D('1.03')/D('.07')/D('1.1')**5+D(50)-D(300))/D(50)
check('Synthetic independent Decimal training answer',close(float(answer),training_dcf.share_value(.10,.03,[.08,.06,.05,.04,.03])),str(answer)+'; course published answer table still needed')
expect=Path(__file__).resolve().parents[2]/'07_Validation_AI_Record/Pre_Run_Expectations.md'
result=dict(executed_utc=datetime.now(timezone.utc).isoformat(),
 expectation_sha256=hashlib.sha256(expect.read_bytes()).hexdigest() if expect.exists() else 'see packaged record',
 checks=checks,passed=sum(x['status']=='PASS' for x in checks),failed=sum(x['status']=='FAIL' for x in checks),
 limitation='AI-assisted suite; does not certify human AI-off authorship, course benchmark receipt or video recording.')
print(json.dumps(result,indent=2))
raise SystemExit(bool(result['failed']))
