"""Offline NVIDIA workbench; Python standard library only. Run python3 workbench.py."""
import json, math, argparse
from copy import deepcopy
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from nvidia_sensitivity import run_case

ROOT = Path(__file__).resolve().parent
BASE = json.loads((ROOT / 'nvidia_base_inputs.json').read_text())
# Bounds are scenario judgments, not confidence intervals or company guidance.
CONTROLS = {
 'growth_shift': ('Growth path shift (percentage points)', -5, 5, 0, .5),
 'margin_shift': ('EBIT margin path shift (percentage points)', -5, 5, 0, .5),
 'tax': ('Operating tax (%)', 16, 20, 17, .5),
 'capex': ('Capital spending / sales (%)', 2, 5, 3, .25),
 'wc': ('Incremental working capital / incremental sales (%)', 15, 30, 20, 1),
 'wacc': ('WACC (%)', 9, 11, 10, .25),
 'terminal': ('Terminal growth (%)', 2.5, 4.5, 3.5, .25),
}

def inputs_for(params):
    unknown = set(params) - set(CONTROLS)
    if unknown: raise ValueError('Unknown controls: ' + str(unknown))
    vals = {}
    for key, (_, lo, hi, default, _) in CONTROLS.items():
        v = float(params.get(key, default))
        if not math.isfinite(v) or not lo <= v <= hi:
            raise ValueError(f'{key}: {v} outside approved range [{lo}, {hi}]')
        vals[key] = v
    b = deepcopy(BASE)
    for key, source in [('GROWTH','growth_shift'),('MARGINS','margin_shift')]:
        b[key] = [v + vals[source]/100 for v in b[key]]
    for key, source in [('TAX','tax'),('CAPEX_RATIO','capex'),('WC_RATIO','wc'),('WACC','wacc'),('TERMINAL_GROWTH','terminal')]:
        b[key] = vals[source]/100
    return b

def calculate(params=None):
    b = inputs_for(params or {})
    result = run_case(b)
    # Original helper can mark the statements valid while valuation fails.
    # Product status requires both; never display a stale usable value.
    if result['valuation'] is None or result['issues']: result['status'] = 'INVALID'
    # Annual FY24–FY26 plus latest reported quarter: a disclosed reference band,
    # not a constraint that historical profitability can never be exceeded.
    margins = [32.972/60.922,81.453/130.497,130.387/215.938,63.734/96.221]
    result['historical_margin_band'] = [min(margins),max(margins)]
    result['history_warning'] = any(not min(margins) <= m <= max(margins) for m in b['MARGINS'])
    return result

def analyze():
    cases = {'Low':calculate({'growth_shift':-5,'margin_shift':-5,'wacc':11,'terminal':2.5}),
             'Base':calculate(),
             'High':calculate({'growth_shift':5,'margin_shift':5,'wacc':9,'terminal':4.5})}
    oat=[]
    for key, (label,lo,hi,default,step) in CONTROLS.items():
        low, high = calculate({key:lo}), calculate({key:hi})
        oat.append(dict(driver=key,label=label,lower=lo,base=default,higher=hi,
                        low=low['outputs'],high=high['outputs'],
                        spans={k:high['outputs'][k]-low['outputs'][k] for k in ('ebit','fcff','per_share')}))
    ranking=[]
    for gs,ms in [(5,5),(1,5),(5,1)]:
        a,b=calculate({'growth_shift':-gs}),calculate({'growth_shift':gs})
        c,d=calculate({'margin_shift':-ms}),calculate({'margin_shift':ms})
        ranking.append(dict(growth_width=gs,margin_width=ms,
          growth_spans={k:b['outputs'][k]-a['outputs'][k] for k in ('ebit','fcff','per_share')},
          margin_spans={k:d['outputs'][k]-c['outputs'][k] for k in ('ebit','fcff','per_share')}))
    grid=[dict(wacc=w,growth=g,value=calculate({'wacc':w,'terminal':g})['outputs']['per_share'])
          for w in (9,10,11) for g in (2.5,3.5,4.5)]
    lo,hi=-.1,.7
    for _ in range(100):
        mid=(lo+hi)/2; b=deepcopy(BASE); b['GROWTH']=[mid]*5
        if run_case(b)['outputs']['per_share'] < 225.73: lo=mid
        else: hi=mid
    return dict(cases=cases,oat=oat,ranking=ranking,grid=grid,reverse_growth=(lo+hi)/2)

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed=urlparse(self.path)
        if parsed.path=='/':
            data=(ROOT/'interface.html').read_bytes(); mime='text/html; charset=utf-8'; code=200
        elif parsed.path=='/api':
            try:
                q={k:v[-1] for k,v in parse_qs(parsed.query).items()}
                if q.pop('stress',None)=='1':
                    # Real engine failure: gross profit cannot fund 85% EBIT.
                    b=deepcopy(BASE); b['MARGINS']=[.85]*5
                    result=run_case(b); result['label']='Incoherent 85% EBIT margin; negative R&D'
                else: result=calculate(q)
                data=json.dumps(result,allow_nan=False).encode(); code=200
            except (ValueError,TypeError) as exc:
                data=json.dumps({'status':'INVALID','issues':[str(exc)]}).encode(); code=400
            mime='application/json'
        elif parsed.path=='/analysis':
            data=json.dumps(analyze(),allow_nan=False).encode(); mime='application/json'; code=200
        else:
            data=b'Not found'; mime='text/plain'; code=404
        self.send_response(code); self.send_header('Content-Type',mime)
        self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(data)

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--export',action='store_true'); p.add_argument('--port',type=int,default=8765)
    args=p.parse_args()
    if args.export:
        (ROOT.parent/'Project1_NVDA_Results.json').write_text(json.dumps(analyze(),indent=2,allow_nan=False)+'\n')
        print('Saved full inputs, five-year statements, checks, scenarios, sensitivities and reverse DCF.')
    else:
        print(f'Open http://127.0.0.1:{args.port} | Ctrl+C stops the local workbench.',flush=True)
        HTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
