"""Annual-basis, qualified peer comparisons. USD billions except price/EPS."""
import json
ROWS=[
 dict(symbol='NVDA',period='2026-01-25',price=225.73,revenue=215.938,eps=4.90,shares=24.514,cash=10.605,securities=51.951,debt=8.468),
 dict(symbol='AMD',period='2025-12-27',price=505.74,revenue=34.639,eps=2.65,shares=1.636,cash=5.539,securities=5.013,debt=3.222),
 dict(symbol='AVGO',period='2025-11-02',price=368.56,revenue=63.887,eps=4.77,shares=4.853,cash=16.178,securities=0,debt=65.136)]
def results():
 out=[]
 for row in ROWS:
  assert all(row[k]>0 for k in ('revenue','eps','shares','price'))
  r=row.copy();r['equity_proxy']=r['price']*r['shares'];r['ev_proxy']=r['equity_proxy']+r['debt']-r['cash']-r['securities'];r['ev_revenue']=r['ev_proxy']/r['revenue'];r['pe']=r['price']/r['eps'];out.append(r)
 return out
if __name__=='__main__':print(json.dumps(results(),indent=2))
