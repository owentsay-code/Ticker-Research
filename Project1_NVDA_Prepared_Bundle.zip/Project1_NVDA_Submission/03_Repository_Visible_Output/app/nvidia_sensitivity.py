"""NVIDIA one-at-a-time sensitivity; run: python3 -B nvidia_sensitivity.py.

Uses the existing linked model, saved base inputs and user-established ranges.
Outputs a Markdown report and full JSON audit trail. No market data is fetched.
"""
from copy import deepcopy
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
from types import ModuleType

ROOT = Path(__file__).resolve().parent
MODEL = ROOT / 'nvidia_proforma.py'
BASE_FILE = ROOT / 'nvidia_base_inputs.json'
RANGES_FILE = ROOT / 'nvidia_sensitivity_ranges.json'
TOL = 1e-8
METRICS = ('ebit', 'fcff', 'per_share')


def fresh_model(inputs):
    module = ModuleType('nvidia_isolated_run')
    module.__file__ = str(MODEL)
    exec(compile(MODEL.read_text(), str(MODEL), 'exec'), module.__dict__)
    for key, val in deepcopy(inputs).items():
        setattr(module, key, val)
    return module


def accounting_checks(model, rows):
    checks = []

    def add(year, name, amount, nonnegative=False):
        passed = math.isfinite(amount) and (amount >= -TOL if nonnegative else abs(amount) <= TOL)
        checks.append(dict(year=year, check=name, amount=amount,
                           units='USD billions', status='PASS' if passed else 'FAIL'))

    prior = model.OPENING
    add(0, 'Opening balance sheet gap', sum(prior[k] for k in model.ASSETS)
        - sum(prior[k] for k in model.LIABILITIES) - prior['equity'])
    for r in rows:
        y = r['year']
        add(y, 'Balance sheet gap', sum(r[k] for k in model.ASSETS)
            - sum(r[k] for k in model.LIABILITIES) - r['equity'])
        add(y, 'Cash reconciliation gap', r['cash'] - prior['cash'] - r['cfo'] - r['cfi'] - r['cff'])
        add(y, 'Equity rollforward gap', r['equity'] - prior['equity'] - r['ni']
            - r['sbc'] + r['buybacks'] + r['dividends'])
        add(y, 'Fixed asset rollforward gap', r['ppe'] + r['intangibles'] - prior['ppe']
            - prior['intangibles'] - r['capex'] + r['da'])
        add(y, 'Working capital gap', model.nwc(r) - model.nwc(prior)
            - model.WC_RATIO * (r['revenue'] - prior['revenue']))
        add(y, 'Income statement gap', r['gross'] - r['sga'] - r['rd'] - r['ebit'])
        add(y, 'FCFF formula gap', r['fcff'] - (r['ebit'] * (1-model.TAX)
            + r['da'] - r['capex'] - r['delta_nwc']))
        if r['pretax'] >= 0:
            add(y, 'FCFE to FCFF bridge gap', r['fcfe'] - r['fcff'] + r['interest'] * (1-model.TAX))
        for key in ('cash', 'ppe', 'intangibles', 'rd'):
            add(y, key + ' nonnegative', r[key], nonnegative=True)
        for key, val in r.items():
            if not math.isfinite(val):
                add(y, key + ' finite', val)
        prior = r
    return checks


def run_case(base, driver=None, path=None, label='Base'):
    inputs = deepcopy(base)
    if driver is not None:
        inputs[driver] = deepcopy(path)
    changed = [k for k in base if inputs[k] != base[k]]
    if changed not in ([], [driver]):
        raise ValueError('More than the selected independent input changed')
    result = dict(label=label, driver=driver, inputs=inputs, changed_inputs=changed,
                  rows=[], checks=[], valuation=None, issues=[], status='INVALID',
                  outputs=dict.fromkeys(METRICS))
    try:
        model = fresh_model(inputs)
        # Explicit growth avoids the original function's definition-time default.
        rows = model.project(growth=inputs['GROWTH'], validate=False)
        result['rows'] = rows
        result['checks'] = accounting_checks(model, rows)
        if len(rows) != 5:
            raise ValueError('Expected all five forecast years')
        result['outputs'].update(ebit=rows[-1]['ebit'], fcff=rows[-1]['fcff'])
        if any(c['status'] == 'FAIL' for c in result['checks']):
            raise ValueError('Accounting or feasibility checks failed; see check details')
        result['status'] = 'VALID'
        try:
            if any(r['pretax'] < 0 for r in rows):
                raise ValueError('Existing FCFF tax convention needs reconciliation for losses')
            if not all(math.isfinite(inputs[k]) for k in ('WACC', 'TERMINAL_GROWTH', 'SHARES')):
                raise ValueError('Nonfinite valuation inputs')
            if inputs['SHARES'] <= 0 or inputs['WACC'] <= -1 or inputs['TERMINAL_GROWTH'] <= -1:
                raise ValueError('Invalid shares or discount/growth inputs')
            val = model.value(rows, wacc=inputs['WACC'], growth=inputs['TERMINAL_GROWTH'])
            if not all(math.isfinite(v) for v in val.values()):
                raise ValueError('Nonfinite valuation result')
            result['valuation'] = val
            result['outputs']['per_share'] = val['per_share']
        except (ValueError, ZeroDivisionError, OverflowError) as exc:
            result['issues'].append('Value per share unavailable: ' + str(exc))
    except (ValueError, ZeroDivisionError, OverflowError) as exc:
        result['issues'].append(str(exc))
    return result


def format_number(v, signed=False, digits=3):
    if v is None or not math.isfinite(v):
        return 'Unavailable'
    return format(v, f'+,.{digits}f' if signed else f',.{digits}f')


def path_text(values):
    return ', '.join(f'{x*100:g}%' for x in values)


def render(data):
    lines = ['# NVIDIA — one-at-a-time sensitivity results', '',
             'Generated: ' + data['timestamp'], '',
             'Source: existing `nvidia_proforma.py`; no new company data. Years 1–5 are rolling annual periods, not fiscal years.', '',
             'Every run uses a fresh isolated model and a deep copy of `nvidia_base_inputs.json`. Only the named driver path changes; all other independent inputs reset to base. Linked statement quantities recalculate. Ranges are the previously selected ±5 percentage points in all five years.', '',
             'Outputs: Year 5 operating profit (EBIT) and economic FCFF in USD billions; value per share in USD/share. Changes and spans use unrounded results. Negative flows remain signed. Invalid runs are flagged and excluded from spans; no ranking is produced.', '',
             'Valuation retains the existing FCFF method: 10% WACC, 3.5% terminal growth, normalized terminal reinvestment, and 24.285 billion shares. These are existing scenario assumptions, not newly verified market inputs.', '',
             '## Actual input paths', '',
             '| Run | Annual revenue growth, Years 1–5 (%) | EBIT margin, Years 1–5 (% of revenue) |',
             '| --- | --- | --- |']
    for r in data['runs']:
        lines.append(f"| {r['label']} | {path_text(r['inputs']['GROWTH'])} | {path_text(r['inputs']['MARGINS'])} |")
    lines += ['', '## Results and signed changes from base', '',
              '| Run | Status | EBIT ($bn) | Δ EBIT ($bn) | FCFF ($bn) | Δ FCFF ($bn) | Value/share ($) | Δ Value/share ($) |',
              '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for r in data['runs']:
        cells = [r['label'], r['status']]
        for key in METRICS:
            digits = 2 if key == 'per_share' else 3
            cells += [format_number(r['outputs'][key], digits=digits), format_number(r['changes'][key], True, digits)]
        lines.append('| ' + ' | '.join(cells) + ' |')
    for r in data['runs']:
        for issue in r['issues']:
            lines.append('')
            lines.append(f"**{r['label']}:** {issue}")
    lines += ['', '## Output spans', '',
              'Maximum minus minimum across valid lower/base/higher results for that driver; unavailable valuation results are excluded from value/share spans.', '',
              '| Driver | EBIT span ($bn) | FCFF span ($bn) | Value/share span ($) | Valid counts: EBIT / FCFF / value |',
              '| --- | ---: | ---: | ---: | --- |']
    for driver, spans in data['spans'].items():
        lines.append('| ' + ' | '.join([data['ranges'][driver]['label']]
                     + [format_number(spans[k]['span'], digits=2 if k == 'per_share' else 3) for k in METRICS]
                     + [' / '.join(str(spans[k]['count']) for k in METRICS)]) + ' |')
    lines += ['', '## Base restoration', '',
              'Final run: **Restored base**. Exact input, statement, and valuation agreement with the initial base: **'
              + ('PASS' if data['base_restored'] else 'FAIL') + '**.', '',
              '## Statement and check audit trail', '',
              'All five years are retained below for every run. All statement fields are USD billions, including the signed FCFF fields. Field names match the existing model: `ebit` = operating profit; `ni` = net income; `da` = depreciation and amortization; `delta_nwc` = investment in operating working capital; `cfo/cfi/cff` = operating/investing/financing cash flow; `fcff` = economic free cash flow to the firm. Expense fields such as `sga`, `rd`, `tax`, and `capex` are positive deductions in their respective formulas.', '',
              'Check amounts are USD billions. Reconciliation tolerance: 0.00000001. Nonnegative checks show balances, not reconciliation gaps. Full inputs, statements, checks, and valuation bridges are also saved in `nvidia_sensitivity_results.json`.']
    for r in data['runs']:
        lines += ['', '### ' + r['label'], '',
                  'Changed independent inputs: ' + (', '.join(r['changed_inputs']) or 'none') + '.', '',
                  '| Statement field ($bn) | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |',
                  '| --- | ---: | ---: | ---: | ---: | ---: |']
        if r['rows']:
            for key in r['rows'][0]:
                if key != 'year':
                    lines.append('| ' + key + ' | ' + ' | '.join(format_number(row[key]) for row in r['rows']) + ' |')
        lines += ['', '| Year | Check | Amount ($bn) | Status |', '| --- | --- | ---: | --- |']
        for c in r['checks']:
            lines.append(f"| {c['year']} | {c['check']} | {c['amount']:.12f} | {c['status']} |")
        if r['valuation']:
            lines += ['', 'Valuation bridge: ' + '; '.join(f'{k}={v:.6f}' for k, v in r['valuation'].items())
                      + '. Amounts are USD billions except per_share (USD/share) and terminal_share (fraction).']
    return '\n'.join(lines) + '\n'


def main():
    base = json.loads(BASE_FILE.read_text())
    saved_base = deepcopy(base)
    ranges = json.loads(RANGES_FILE.read_text())
    for driver, spec in ranges.items():
        if spec['base'] != base[driver] or spec['years'] != [1, 2, 3, 4, 5]:
            raise ValueError('Saved ranges must agree with the base and specified years')
        if any(len(spec[level]) != 5 for level in ('lower', 'base', 'higher')):
            raise ValueError('Each input path must have five values')
    runs = [run_case(base, label='Initial base')]
    for driver, spec in ranges.items():
        for level in ('lower', 'base', 'higher'):
            runs.append(run_case(base, driver, spec[level], spec['label'] + ': ' + level))
    # Final full model run is explicitly a restored base, not reused cached output.
    runs.append(run_case(saved_base, label='Restored base'))
    restored = base == saved_base and all(runs[0][k] == runs[-1][k]
                                         for k in ('inputs', 'rows', 'valuation', 'checks', 'status'))
    for r in runs:
        r['changes'] = {k: r['outputs'][k] - runs[0]['outputs'][k]
                        if r['status'] == runs[0]['status'] == 'VALID'
                        and r['outputs'][k] is not None and runs[0]['outputs'][k] is not None
                        else None for k in METRICS}
    spans = {}
    for driver in ranges:
        spans[driver] = {}
        for key in METRICS:
            valid = [r['outputs'][key] for r in runs if r['driver'] == driver
                     and r['status'] == 'VALID' and r['outputs'][key] is not None]
            spans[driver][key] = dict(count=len(valid), span=max(valid)-min(valid) if valid else None)
    data = dict(company='NVIDIA', timestamp=datetime.now().astimezone().isoformat(),
                model_sha256=hashlib.sha256(MODEL.read_bytes()).hexdigest(),
                base_inputs=saved_base, ranges=ranges, runs=runs, spans=spans, base_restored=restored)
    (ROOT / 'nvidia_sensitivity_results.json').write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')
    report = ROOT / 'NVIDIA - Sensitivity Results.md'
    report.write_text(render(data))
    print(report)
    print(f'{len(runs)} full model runs; base restoration: {"PASS" if restored else "FAIL"}')
    for r in runs:
        print(r['label'], r['status'], r['outputs'], r['issues'])
    if not restored:
        raise SystemExit('Base restoration failed')


if __name__ == '__main__':
    main()
