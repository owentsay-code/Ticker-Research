# Run and review

Python 3.10+; standard library only; no installs, keys, credentials or external accounts. Start in `app`.

```bash
python3 workbench.py
```

Open http://127.0.0.1:8765. Stop with Ctrl+C. Alternative port: `python3 workbench.py --port 8766`.

```bash
python3 -B validate.py
python3 -B workbench.py --export
python3 -B peer_comparison.py
```

`validate.py` exits nonzero on a failed check. It is not proof of student AI-off work. Export replaces the generated Results JSON in this repository; it does not change the original research files. The packaged HTML/Markdown visible output is a frozen snapshot; regenerate those presentation files if assumptions are edited outside the panel. Changes in the panel are transient and do not rewrite the frozen base.

Architecture: `nvidia_base_inputs.json` + `nvidia_proforma.py` → `nvidia_sensitivity.py` isolated runs → `workbench.py` control validation and scenarios → `interface.html`. Accounting/provenance are not editable through the panel. `training_dcf.py` is the separate synthetic example. `peer_comparison.py` is the annual peer diagnostic.

`archive` contains earlier files with their original dates, conventions and caveats. For the final active conclusion, use Edition B and the committee memo. Older dates and single-value language are historical evidence, not competing final recommendations.

Open `Project1_NVDA_Visible_Output.html` without running Python to see the full base statements, bridge, sensitivities and checks. JSON retains full scenario rows. Read the evidence ledger for all financial source definitions, normalization and exclusions.

Cold run: create a new virtual environment, copy the app to a clean directory, execute the validation suite and export, start the server and operate the panel. No installation step is required. The automated clean-environment log is in part 7; the student's recorded demonstration remains outstanding.
