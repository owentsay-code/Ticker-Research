# Using Python

Python 3.14.7 is installed on this computer. This project also has an isolated environment in `.venv`.

From a terminal in this project folder, activate it:

```bash
source .venv/bin/activate
```

Then you can start Python, run a script, or install packages:

```bash
python
python your_script.py
python -m pip install package_name
```

Exit the Python prompt with `exit()`. Leave the environment with `deactivate`.
Activate the environment again when you open a new terminal.

You can also run Python without activation:

```bash
.venv/bin/python your_script.py
```

Outside this project, use `python3` to run the computer's installed Python.
