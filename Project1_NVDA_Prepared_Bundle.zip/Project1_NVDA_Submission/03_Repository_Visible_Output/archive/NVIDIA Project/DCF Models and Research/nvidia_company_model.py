"""Five-year rolling FCFF DCF as of September 8, 2026; USD billions.

Run: .venv/bin/python nvidia_company_model.py [market_price]
Sources and modeling conventions: NVIDIA - Full Valuation Report - Sep 08.md.
"""
import json
import sys

REVENUE = 215.938 + 177.837 - 90.805
SHARES = 24.285  # Latest quarterly diluted average, proxy for current dilution.
BRIDGE = 22.443 + 34.143 + 42.783 - 1.000 - 32.366
GROWTH = [.45, .30, .20, .15, .10]
MARGINS = [.64, .62, .60, .59, .58]


def valuation(growth=GROWTH, wacc=.10, terminal_growth=.035):
    revenue = REVENUE
    rows = []
    for year, (rate, margin) in enumerate(zip(growth, MARGINS), 1):
        previous = revenue
        revenue *= 1 + rate
        ebit = revenue * margin
        nopat = ebit * (1 - .17)
        da, capex, delta_nwc = revenue * .012, revenue * .03, (revenue - previous) * .20
        fcff = nopat + da - capex - delta_nwc
        rows.append(dict(year=year, revenue=revenue, ebit=ebit, nopat=nopat,
                         da=da, capex=capex, delta_nwc=delta_nwc, fcff=fcff,
                         pv=fcff / (1 + wacc) ** year))
    next_revenue = revenue * (1 + terminal_growth)
    terminal_fcff = next_revenue * (MARGINS[-1] * .83 + .012 - .03) - .20 * revenue * terminal_growth
    terminal_pv = terminal_fcff / (wacc - terminal_growth) / (1 + wacc) ** 5
    explicit_pv = sum(row['pv'] for row in rows)
    ev = explicit_pv + terminal_pv
    return dict(rows=rows, explicit_pv=explicit_pv, terminal_pv=terminal_pv,
                enterprise_value=ev, equity_value=ev + BRIDGE,
                price=(ev + BRIDGE) / SHARES, terminal_share=terminal_pv / ev)


def implied_growth(price):
    low, high = -.20, 1.50
    assert valuation([low]*5)['price'] <= price <= valuation([high]*5)['price']
    for _ in range(100):
        mid = (low + high) / 2
        if valuation([mid]*5)['price'] < price:
            low = mid
        else:
            high = mid
    return (low + high) / 2


if __name__ == '__main__':
    price = float(sys.argv[1]) if len(sys.argv) > 1 else 225.73  # September 8, 2026 regular-session close; see report.
    result = valuation()
    rate = implied_growth(price)
    assert abs(valuation([rate]*5)['price'] - price) < 1e-8
    result.update(market_price=price, upside=result['price']/price-1,
                  implied_revenue_cagr=rate, implied_year5_revenue=REVENUE*(1+rate)**5,
                  base_revenue_cagr=(result['rows'][-1]['revenue']/REVENUE)**.2-1,
                  sensitivity={str(w): {str(g): valuation(wacc=w, terminal_growth=g)['price']
                                       for g in [.025, .035, .045]} for w in [.09, .10, .11]})
    print(json.dumps(result, indent=2))
