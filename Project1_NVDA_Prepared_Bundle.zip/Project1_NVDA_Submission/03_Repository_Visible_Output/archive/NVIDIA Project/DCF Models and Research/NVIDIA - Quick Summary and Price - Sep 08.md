# NVIDIA DCF — table and price

Snapshot: September 8, 2026.

- Comparison stock price: **$225.73 per share**, September 8 regular-session close.
- DCF base value: **$209.28 per share**.
- Difference versus closing price: **7.3% downside**.

## Five-year forecast

All amounts below are USD billions.

| Future year | Revenue | EBIT | NOPAT | D&A | Capex | ΔNWC | FCFF |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 439.3 | 281.2 | 233.4 | 5.3 | 13.2 | 27.3 | 198.2 |
| 2 | 571.1 | 354.1 | 293.9 | 6.9 | 17.1 | 26.4 | 257.2 |
| 3 | 685.3 | 411.2 | 341.3 | 8.2 | 20.6 | 22.8 | 306.1 |
| 4 | 788.1 | 465.0 | 385.9 | 9.5 | 23.6 | 20.6 | 351.2 |
| 5 | 866.9 | 502.8 | 417.3 | 10.4 | 26.0 | 15.8 | 386.0 |

Source: [saved September 8 DCF report](<NVIDIA - Full Valuation Report - Sep 08.md>). Price verified September 17, 2026 at [Stock Analysis](https://stockanalysis.com/stocks/nvda/history/), Historical Data → Sep 8, 2026 → Close. The earlier $226.00 intraday quote is superseded. DCF assumptions are unchanged. See [candidate comparison](<../Canidates.md>) for the same-date AMD and Broadcom closes.
