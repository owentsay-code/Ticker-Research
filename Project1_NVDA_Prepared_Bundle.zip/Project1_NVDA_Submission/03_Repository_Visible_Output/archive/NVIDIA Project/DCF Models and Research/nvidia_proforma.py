"""NVIDIA linked pro forma and assignment report. USD billions unless specified.

Run with Python 3; writes the adjacent Markdown report. Standard library only.
Sources, judgments, and limitations are included in the generated report.
"""
from pathlib import Path
import math

ROOT = Path(__file__).resolve().parent
SOURCES = {
    'K24': 'https://www.sec.gov/Archives/edgar/data/1045810/000104581024000029/nvda-20240128.htm',
    'K25': 'https://www.sec.gov/Archives/edgar/data/1045810/000104581025000023/nvda-20250126.htm',
    'K26': 'https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/nvda-20260125.htm',
    'Q27': 'https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Announces-Financial-Results-for-Second-Quarter-Fiscal-2027/default.aspx',
    'Provider': 'https://stockanalysis.com/stocks/nvda/financials/cash-flow-statement/',
}
# Each annual observation is attributed to that year's own 10-K.
HISTORY = [
    dict(year=2024, source='K24', end='2024-01-28', revenue=60922, gross=44301,
         sga=2654, ni=29760, inventory=5282, ppe=3914, equity=42978,
         dep=894, da=1508, capex=1069, principal=74, tax=4058, pretax=33818,
         prior_revenue=26974, cfo=28090, debt_repaid=1250),
    dict(year=2025, source='K25', end='2025-01-26', revenue=130497, gross=97858,
         sga=3491, ni=72880, inventory=10080, ppe=6283, equity=79327,
         dep=1300, da=1864, capex=3236, principal=129, tax=11146, pretax=84026,
         prior_revenue=60922, cfo=64089, debt_repaid=1250),
    dict(year=2026, source='K26', end='2026-01-25', revenue=215938, gross=153463,
         sga=4579, ni=120067, inventory=21403, ppe=10383, equity=157293,
         dep=2400, da=2843, capex=6042, principal=101, tax=21383, pretax=141450,
         prior_revenue=130497, cfo=102718, debt_repaid=0),
]
BASE_REVENUE = 215.938 + 177.837 - 90.805
OPENING = dict(cash=22.443, securities=76.926, ar=63.059, inventory=31.575,
               prepaid=3.409, ppe=14.285, intangibles=2.998, other_assets=105.577,
               ap=15.059, accrued=26.960, debt=33.366, other_liabilities=15.903,
               equity=228.984, revenue=BASE_REVENUE)
GROWTH = (.45, .30, .20, .15, .10)
MARGINS = (.64, .62, .60, .59, .58)
GROSS_MARGINS = (.74, .73, .72, .71, .70)
TAX, DA_RATIO, CAPEX_RATIO, WC_RATIO = .17, .012, .03, .20
SBC_RATIO, INTEREST_RATE = .022, .04
SHARES, DIVIDENDS = 24.285, 24.285
WACC, TERMINAL_GROWTH = .10, .035
WC_ASSETS, WC_LIABILITIES = ('ar', 'inventory', 'prepaid'), ('ap', 'accrued')
ASSETS = ('cash', 'securities', 'ar', 'inventory', 'prepaid', 'ppe', 'intangibles', 'other_assets')
LIABILITIES = ('ap', 'accrued', 'debt', 'other_liabilities')


def nwc(row):
    return sum(row[k] for k in WC_ASSETS) - sum(row[k] for k in WC_LIABILITIES)


def near(a, b, name):
    if not math.isfinite(a) or not math.isfinite(b) or abs(a-b) > 1e-8:
        raise ValueError(f'{name}: {a} != {b}')


def project(growth=GROWTH):
    near(sum(OPENING[k] for k in ASSETS), 320.272, 'Opening assets')
    near(sum(OPENING[k] for k in LIABILITIES) + OPENING['equity'], 320.272, 'Opening balance')
    prior = OPENING.copy()
    rows = []
    for t, (growth_rate, margin, gross_margin) in enumerate(zip(growth, MARGINS, GROSS_MARGINS), 1):
        r = prior.copy()
        r.update(year=t, opening_cash=prior['cash'], opening_equity=prior['equity'])
        r['revenue'] = prior['revenue'] * (1+growth_rate)
        r['gross'] = r['revenue'] * gross_margin
        r['cogs'] = r['revenue'] - r['gross']
        r['sga'] = r['gross'] * .03
        r['ebit'] = r['revenue'] * margin
        r['rd'] = r['gross'] - r['sga'] - r['ebit']
        r['da'] = r['revenue'] * DA_RATIO
        r['amortization'] = min(prior['intangibles'], r['da'] * .15)
        r['depreciation'] = r['da'] - r['amortization']
        r['interest'] = prior['debt'] * INTEREST_RATE
        r['pretax'] = r['ebit'] - r['interest']
        r['tax'] = max(0, r['pretax']) * TAX
        r['ni'] = r['pretax'] - r['tax']
        r['capex'] = r['revenue'] * CAPEX_RATIO
        r['ppe'] = prior['ppe'] + r['capex'] - r['depreciation']
        r['intangibles'] = prior['intangibles'] - r['amortization']
        delta_nwc = (r['revenue']-prior['revenue']) * WC_RATIO
        for k in WC_ASSETS + WC_LIABILITIES:
            r[k] = prior[k] + delta_nwc * OPENING[k] / nwc(OPENING)
        r['delta_nwc'] = nwc(r) - nwc(prior)
        r['sbc'] = r['revenue'] * SBC_RATIO
        r['buybacks'] = r['sbc']
        r['dividends'] = DIVIDENDS
        r['net_borrowing'] = 0.0
        r['cfo'] = r['ni'] + r['da'] + r['sbc'] - r['delta_nwc']
        r['cfi'] = -r['capex']
        r['cff'] = r['net_borrowing'] - r['buybacks'] - r['dividends']
        r['cash_change'] = r['cfo'] + r['cfi'] + r['cff']
        r['cash'] = prior['cash'] + r['cash_change']
        r['equity'] = prior['equity'] + r['ni'] + r['sbc'] - r['buybacks'] - r['dividends']
        r['assets'] = sum(r[k] for k in ASSETS)
        r['liabilities'] = sum(r[k] for k in LIABILITIES)
        r['balance_gap'] = r['assets'] - r['liabilities'] - r['equity']
        r['cash_fcfe'] = r['cfo'] - r['capex'] + r['net_borrowing']
        r['fcfe'] = r['cash_fcfe'] - r['sbc']
        r['fcff'] = r['ebit'] * (1-TAX) + r['da'] - r['capex'] - r['delta_nwc']
        near(r['balance_gap'], 0, f'Year {t} balance sheet')
        near(r['cash']-prior['cash'], r['cash_change'], f'Year {t} cash')
        near(r['equity']-prior['equity'], r['ni']+r['sbc']-r['buybacks']-r['dividends'], f'Year {t} equity')
        near(r['delta_nwc'], delta_nwc, f'Year {t} working capital')
        near(r['ppe']+r['intangibles'], prior['ppe']+prior['intangibles']+r['capex']-r['da'], f'Year {t} assets rollforward')
        # This bridge presumes a positive taxable profit (true in this base case).
        if r['pretax'] >= 0:
            near(r['fcfe'], r['fcff']-r['interest']*(1-TAX), f'Year {t} FCFE bridge')
        if r['cash'] < 0 or r['ppe'] < 0 or r['intangibles'] < 0:
            raise ValueError(f'Year {t}: negative cash or fixed assets; revise financing assumptions')
        rows.append(r)
        prior = r
    return rows


def value(rows, wacc=WACC, growth=TERMINAL_GROWTH):
    if wacc <= growth:
        raise ValueError('Discount rate must exceed terminal growth')
    last = rows[-1]
    next_revenue = last['revenue'] * (1+growth)
    terminal_fcff = next_revenue * (MARGINS[-1]*(1-TAX)+DA_RATIO-CAPEX_RATIO) - WC_RATIO*last['revenue']*growth
    if terminal_fcff <= 0:
        raise ValueError('Nonpositive terminal FCFF: stable positive cash flow must be established first')
    explicit = sum(r['fcff']/(1+wacc)**r['year'] for r in rows)
    terminal = terminal_fcff/(wacc-growth)
    pv_terminal = terminal/(1+wacc)**5
    ev = explicit + pv_terminal
    bridge = OPENING['cash'] + OPENING['securities'] - OPENING['debt']
    return dict(explicit=explicit, terminal_fcff=terminal_fcff, terminal=terminal,
                pv_terminal=pv_terminal, ev=ev, bridge=bridge, equity=ev+bridge,
                per_share=(ev+bridge)/SHARES, terminal_share=pv_terminal/ev)


def link(key):
    return f'[{key}]({SOURCES[key]})'


def table(headers, rows):
    return '\n'.join(['| '+' | '.join(headers)+' |', '| '+' | '.join(['---']*len(headers))+' |'] +
                     ['| '+' | '.join(map(str, row))+' |' for row in rows])


def forecast_table(rows, fields):
    return table(['USD billions']+[f'Year {r["year"]}' for r in rows],
                 [[label]+[f'{(r[key]*sign if abs(r[key]) > 1e-8 else 0):,.3f}' for r in rows]
                  for label, key, sign in fields])


def report(rows):
    v = value(rows)
    parts = ['# NVIDIA five year pro forma and valuation',
             '**NVIDIA Corporation | NASDAQ NVDA | Prepared September 24, 2026**',
             f'This report adapts the ABG exercise to NVIDIA. It includes a three-year history grid, ratios, assumptions, four linked projected statements and a cash flow valuation. The base case produces **${v["per_share"]:,.2f} per share**, with all five years showing positive FCFE. This is a scenario based on stated assumptions, not company guidance or a market price.',
             '## Scope and dates',
             'History uses FY2024, FY2025 and FY2026, each from its own 10-K. The projection uses the latest July 26, 2026 balance sheet and trailing twelve month revenue of $302.970 billion (215.938 + 177.837 − 90.805). Year 1–5 are full future annual periods from the September 24 modeling date, approximately through September 2031; they are not NVIDIA fiscal years. The July balance sheet is a proxy for the valuation-date balance sheet; the reporting lag is not separately rolled forward. This follows the rolling-period convention of the earlier NVIDIA report. ['+'FY2026 filing]('+SOURCES['K26']+') and '+link('Q27')+'.',
             'Historical amounts below are USD millions; forecast amounts are USD billions. Parentheses or minus signs indicate deductions. Rounding may cause displayed sums to differ slightly.',
             '## Three year history with a source on every item']
    grid = []
    for label, key, locator in [('Revenue','revenue','income statement'), ('Gross profit','gross','income statement'),
                               ('SG&A','sga','income statement'), ('Net income','ni','income statement'),
                               ('Inventory','inventory','balance sheet'), ('PP&E net','ppe','balance sheet'),
                               ("Shareholders’ equity",'equity','balance sheet')]:
        grid.append([label]+[f'{h[key]:,} — {link(h["source"])} {locator}' for h in HISTORY])
    parts += [table(['USD millions','FY2024 · Jan 28 2024','FY2025 · Jan 26 2025','FY2026 · Jan 25 2026'],grid),
              '## Two filing checks',
              f'The AI opened and checked FY2026 revenue of **$215,938 million** in the Consolidated Statements of Income, printed page 51 of {link("K26")}, and FY2024 inventory of **$5,282 million** in the Consolidated Balance Sheets, printed page 52 of {link("K24")}. Both match this grid.',
              '## Supporting inputs for the ratios']
    inputs = [('Cost of revenue','cogs'),('Depreciation only','dep'),('Depreciation and amortization','da'),
              ('Income tax expense','tax'),('Pretax income','pretax'),('Prior year revenue','prior_revenue')]
    parts += [table(['USD millions','FY2024','FY2025','FY2026'],
                    [[name]+[f'{(h["revenue"]-h["gross"] if key=="cogs" else h[key]):,} — {link(h["source"])}' for h in HISTORY] for name,key in inputs]),
              'Depreciation-only amounts come from the PP&E note; FY2025 and FY2026 are disclosed rounded to $1.3 billion and $2.4 billion, so their depreciation ratios are approximate. D&A comes from the cash flow statement and includes intangible amortization. These are different measures.',
              '## Three year ratio table']
    ratios = [
        ('Gross margin',lambda h:h['gross']/h['revenue']*100,'%'),
        ('SG&A ÷ gross profit',lambda h:h['sga']/h['gross']*100,'%'),
        ('Inventory days using ending inventory',lambda h:h['inventory']/(h['revenue']-h['gross'])*365,' days'),
        ('Depreciation only ÷ ending net PP&E',lambda h:h['dep']/h['ppe']*100,'%'),
        ('D&A ÷ ending net PP&E for comparison',lambda h:h['da']/h['ppe']*100,'%'),
        ('Effective tax rate',lambda h:h['tax']/h['pretax']*100,'%'),
        ('Reported revenue growth calculated',lambda h:(h['revenue']/h['prior_revenue']-1)*100,'%'),
    ]
    parts += [table(['Ratio','FY2024','FY2025','FY2026'],
                    [[name]+[f'{fn(h):.2f}{suffix} — {link(h["source"])}' for h in HISTORY] for name,fn,suffix in ratios]),
              'Gross margin = gross profit ÷ revenue. Inventory days = ending inventory ÷ cost of revenue × 365. Tax rate = income tax expense ÷ pretax income. Reported growth = current revenue ÷ prior revenue − 1. Ending balances follow the supplied ABG script; average-balance ratios would differ. The video itself was not supplied, so an exact match to its denominator convention is **unresolved**.',
              table(['Growth measure','FY2024','FY2025','FY2026'],[
                  ['MD&A rounded reported growth']+[f'{g}% — {link(h["source"])}' for g,h in zip((126,114,65),HISTORY)],
                  ['Separate organic growth']+[f'Not found in reviewed filing — {link(h["source"])}' for h in HISTORY],
                  ['Same store growth']+[f'Not applicable to this semiconductor business; not disclosed — {link(h["source"])}' for h in HISTORY]]),
              'Reported growth is not relabeled organic growth. The contribution from acquisitions cannot be separated into a verified organic-growth percentage from these disclosures and remains **unresolved**.',
              '## Capital spending filing and provider comparison',
              table(['USD millions','FY2024','FY2025','FY2026'],[
                  ['Filing purchases of PP&E and intangibles']+[f'{h["capex"]:,} — {link(h["source"])} cash flows' for h in HISTORY],
                  ['Stock Analysis Capital Expenditures signed field']+[f'−{h["capex"]:,} — {link("Provider")}' for h in HISTORY],
                  ['Additional principal payments on PP&E and intangibles']+[f'{h["principal"]:,} — {link(h["source"])} cash flows' for h in HISTORY],
                  ['Combined cash spending calculated']+[f'{h["capex"]+h["principal"]:,} — {link(h["source"])}' for h in HISTORY]]),
              'The provider field matches the investing cash-flow purchases after reversing the sign. It excludes the separately reported financing principal payments. Combined spending equals purchases plus those principal payments; it excludes acquisitions and strategic investments. The forecast assumes all new capital expenditure is paid in cash and no new asset financing, so there is no separate projected principal-payment line. Stock Analysis was chosen because the assignment did not name a provider.',
              '## Assumptions',
              'The reasons below are draft analytical explanations for you to review and put into your own words. “History” labels observed facts; carrying a historical figure forward is labeled “Judgment.”']
    assumptions = [
        ('Starting revenue $302.970bn and July opening balances','history','Reported inputs from K26 and Q27; the TTM revenue bridge is shown above.'),
        ('Quarterly outlook revenue $108bn ±2%; gross margin 74% ±0.5%; FY27 tax 16–18%','guidance','Q27 outlook provides a near-term reference, not a five-year forecast.'),
        ('Revenue growth 45%, 30%, 20%, 15%, 10%','judgment','Retain the earlier NVIDIA scenario. Growth slows as the revenue base expands; Year 1 revenue of $439.3bn is near four times the $108bn quarterly outlook, but that annualization is only a reasonableness check.'),
        ('Gross margin 74%, 73%, 72%, 71%, 70%','judgment','Begin near the quarterly outlook, then allow pricing and competition to reduce margins.'),
        ('SG&A 3% of gross profit','judgment','Round the FY2026 ratio of about 2.98%; assume selling and administrative costs scale with gross profit.'),
        ('EBIT margin 64%, 62%, 60%, 59%, 58%; R&D is the remaining operating expense','judgment','Retain the prior operating-margin path while allowing R&D intensity to rise. R&D equals gross profit less SG&A less EBIT; this is a scenario allocation, not independent company guidance.'),
        ('D&A 1.2% of revenue; up to 15% of D&A assigned to existing intangibles','judgment','Use the earlier model’s rounded reinvestment assumption. Allocate the remainder to depreciation and cap amortization at the remaining intangible balance; this avoids depreciating intangible assets through PP&E.'),
        ('Capital spending 3% of revenue, all new spending assigned to PP&E','judgment','Allow more spending than the recent annual purchases ratio to support growth. All-cash PP&E additions simplify the schedule; future acquired technology would require a separate intangible forecast.'),
        ('Incremental operating working capital 20% of additional revenue','judgment','Retain the prior model’s allowance for receivables, inventory and supplier funding. Spread the net investment across accounts in proportion to their opening balances; this is not a separate inventory-days forecast.'),
        ('Forecast tax rate 17%','judgment','Use the midpoint of the 16–18% outlook as a normalized rate and extend it beyond the guidance period. Cash tax equals book tax; no tax benefit is recognized on a loss.'),
        ('Floor plan financing none; accounts payable modeled separately','history','No dealer floor plan balance is reported. Accounts payable represents supplier credit and must not be renamed floor plan debt.'),
        ('Debt $33.366bn constant; net borrowing zero; interest 4%','judgment','Assume maturities are refinanced at equal principal. A normalized 4% cost avoids using the old interest expense on a materially larger current debt balance; no net new borrowing or refinancing fees are forecast.'),
        ('Stock compensation 2.2% of revenue; offsetting buybacks equal that expense','judgment','Approximate the first-half stock compensation ratio. Buybacks offset the modeled expense economically; equal dollars do not establish the actual share dilution offset.'),
        ('Dividends $24.285bn per year; share proxy 24.285bn fixed','judgment','Annualize the $0.25 quarterly dividend using the latest diluted-share proxy. Assume no net share change and no additional discretionary buybacks; this is not management’s capital-return plan.'),
        ('Other assets and liabilities and securities fixed; investment income and gains zero; OCI zero','judgment','Isolate operating performance without forecasting investment returns or acquisitions. Excess cash accumulates with no assumed yield, understating income if it earns interest.'),
        ('Minimum cash zero; no revolver','judgment','Require cash to remain nonnegative. Forecast operations fund spending and dividends; a cash deficit would require revising financing, not hiding it in equity.'),
        ('WACC 10%; terminal growth 3.5%','judgment','Retain the earlier required return and long-run nominal growth assumptions. They are scenario inputs, not an independently estimated current CAPM result.'),
        ('Terminal ratios at Year 5; working capital recalculated at 3.5% growth','judgment','Model a stable business with continued reinvestment; do not compound the unusually high-growth Year 5 working-capital charge into perpetuity.'),
        ('Equity bridge +$66.003bn','judgment','Add opening cash and marketable securities, subtract debt; treat those assets as available at carrying value without realization tax. Exclude nonmarketable holdings from value pending a realizable-value assessment.'),
    ]
    parts += [table(['Value','Label','Reason'],assumptions),
              'Opening facts and guidance source: '+link('Q27')+'. Earlier scenario reference: [NVIDIA Full Valuation Report September 8](<NVIDIA - Full Valuation Report - Sep 08.md>).',
              '## Income statement',
              forecast_table(rows,[('Revenue','revenue',1),('Cost of revenue','cogs',-1),('Gross profit','gross',1),('SG&A','sga',-1),('R&D','rd',-1),('Operating income EBIT','ebit',1),('Interest expense','interest',-1),('Pretax income','pretax',1),('Income tax','tax',-1),('Net income','ni',1)]),
              'Depreciation, amortization and stock compensation are already included within cost of revenue, SG&A and R&D. They are not deducted again as separate income-statement expenses.',
              '## Balance sheet']
    balance_fields = [('Cash','cash',1),('Marketable securities','securities',1),('Accounts receivable','ar',1),('Inventory','inventory',1),('Prepaid and other current assets','prepaid',1),('PP&E net','ppe',1),('Intangibles net','intangibles',1),('Other noncurrent assets','other_assets',1),('Total assets','assets',1),('Accounts payable','ap',1),('Accrued and other current liabilities','accrued',1),('Interest bearing debt','debt',1),('Other noncurrent liabilities','other_liabilities',1),('Total liabilities','liabilities',1),('Shareholders equity','equity',1)]
    opening = OPENING | dict(assets=320.272, liabilities=91.288)
    parts += [table(['USD billions','Opening July 2026']+[f'Year {r["year"]}' for r in rows],
                    [[label,f'{opening[key]:,.3f}']+[f'{r[key]:,.3f}' for r in rows] for label,key,_ in balance_fields]),
              'Opening balances: '+link('Q27')+'. Other noncurrent assets combine operating lease assets, goodwill, deferred tax assets, nonmarketable securities and other assets. Other noncurrent liabilities combine long-term operating leases and other long-term liabilities. Operating leases remain operating costs; they are not also deducted as financial debt in valuation.',
              'Operating working capital = receivables + inventory + prepaid assets − payables − accrued current liabilities. Opening net working capital is $56.024bn. For each account, the annual change equals 20% of revenue growth in dollars × that account’s opening balance ÷ $56.024bn. This allocation reconciles exactly to the total investment; cash is calculated from the cash flow statement, not used to force a balance.',
              '## Cash flow statement',
              forecast_table(rows,[('Net income','ni',1),('D&A add back','da',1),('Stock compensation add back','sbc',1),('Increase in operating working capital','delta_nwc',-1),('Operating cash flow','cfo',1),('Capital spending and investing cash flow','cfi',1),('Net borrowing','net_borrowing',1),('Offsetting share buybacks','buybacks',-1),('Dividends','dividends',-1),('Financing cash flow','cff',1),('Net change in cash','cash_change',1),('Opening cash','opening_cash',1),('Closing cash','cash',1)]),
              '## Statement of changes in equity',
              forecast_table(rows,[('Opening equity','opening_equity',1),('Net income','ni',1),('Stock compensation equity credit','sbc',1),('Share buybacks','buybacks',-1),('Dividends','dividends',-1),('Closing equity','equity',1)]),
              'No additional stock issuance, other comprehensive income, or repurchase excise taxes are modeled. Stock compensation credits equity and is added back to net income in operating cash flow; the offsetting buyback is a financing outflow.',
              '## FCFE and FCFF',
              forecast_table(rows,[('Cash FCFE before shareholder distributions','cash_fcfe',1),('Less stock compensation economic cost','sbc',-1),('FCFE after stock compensation cost','fcfe',1),('FCFF after stock compensation cost','fcff',1)]),
              table(['FCFE status']+[f'Year {r["year"]}' for r in rows],[['Economic FCFE']+['negative FCFE' if r['fcfe']<0 else 'Positive FCFE' for r in rows]]),
              'Cash FCFE = operating cash flow − capital spending + net borrowing. Economic FCFE here subtracts stock compensation so the valuation does not treat dilution as free cash. Economic FCFF = EBIT × (1 − tax) + D&A − capital spending − change in operating working capital. Economic FCFE = economic FCFF − after-tax interest + net borrowing in this positive-profit base case. Dividends and discretionary buybacks are uses of FCFE, not costs deducted to calculate standard FCFE.',
              '## Valuation',
              'The primary valuation discounts economic FCFF at WACC, consistent with the earlier NVIDIA model. FCFE is shown to satisfy the assignment and reconcile the statements; it is not discounted at WACC.',
              table(['Measure','Base case'],[
                  ['PV of five explicit years of FCFF',f'${v["explicit"]:,.3f}bn'],
                  ['Year 6 normalized FCFF',f'${v["terminal_fcff"]:,.3f}bn'],
                  ['Terminal value at end of Year 5',f'${v["terminal"]:,.3f}bn'],
                  ['PV of terminal value',f'${v["pv_terminal"]:,.3f}bn'],
                  ['Enterprise value',f'${v["ev"]:,.3f}bn'],
                  ['Opening cash plus securities less debt',f'${v["bridge"]:,.3f}bn'],
                  ['Equity value',f'${v["equity"]:,.3f}bn'],
                  ['Diluted shares proxy','24.285bn'],['Value per share',f'${v["per_share"]:,.2f}'],
                  ['Terminal share of enterprise value',f'{v["terminal_share"]:.1%}']]),
              'Terminal value = normalized Year 6 FCFF ÷ (10% − 3.5%); discount it by 1.10 to the fifth power. Add only opening nonoperating assets to enterprise value; adding the forecast cash pile as well would count retained cash flows twice.',
              table(['WACC / terminal growth','2.5%','3.5%','4.5%'],[[f'{w:.0%}']+[f'${value(rows,w,g)["per_share"]:,.2f}' for g in (.025,.035,.045)] for w in (.09,.10,.11)]),
              'The point estimate matches the earlier $209.28 result because the economic FCFF assumptions are unchanged. The new statement schedules explain how operating cash, financing and book equity reconcile; they do not independently validate those valuation assumptions.',
              '## Losses and negative cash flow',
              'NVIDIA has positive historical net income and positive historical operating cash flow less the combined capital-spending measure in all three years. All five projected economic FCFE values are positive, so the assignment’s negative-FCFE exception is not triggered.',
              'If a revised scenario has negative FCFE, retain that year’s full statements and label it “negative FCFE.” If the assignment requires valuing only positive amounts, show the PV of positive flows as a separately labeled assignment subtotal; excluding funding deficits is not a complete equity valuation. Do not substitute FCFF for a negative FCFE without explanation.',
              '**A perpetually negative terminal cash flow cannot support a meaningful positive going-concern equity value without a credible path to sustainable positive cash flow; the formula can return a negative number, but that is not a defensible positive terminal valuation.**',
              '## Model checks',
              forecast_table(rows,[('Assets less liabilities less equity','balance_gap',1)]),
              'PASS in every year: balance sheet balances; operating plus investing plus financing cash reconciles to ending cash; equity rolls forward; PP&E and intangibles roll forward; working-capital investment agrees with the account changes; FCFE reconciles with FCFF after interest; cash stays nonnegative. Calculations use unrounded values with a $10 tolerance (0.00000001 billion).',
              '## Unresolved items and limitations',
              '- The video and full Part 1 template were not provided; the selected ratio denominators follow the ABG script and are explicitly shown.\n- A separate organic-growth percentage is unresolved; none was found in the reviewed filings. Same-store growth is not applicable.\n- The assignment’s preferred data provider was not specified; Stock Analysis was checked and the capital-spending fields reconciled.\n- The model is condensed. Detailed debt maturities, asset additions by class, share dilution, acquisition spending, deferred taxes, future investments and a current estimated cost of capital are not independently forecast. Nonmarketable securities remain on the accounting balance sheet but are excluded from the valuation bridge pending a realizable-value assessment.\n- No live stock quote is used and no current upside or downside percentage is claimed.',
              '## Source register',
              table(['ID','Document','Locator'],[[link('K24'),'FY2024 10-K','Income p50; balance p52; cash flows p54; PP&E note p69; MD&A Item 7'],[link('K25'),'FY2025 10-K','Income p52; balance p54; cash flows; PP&E note; MD&A Item 7'],[link('K26'),'FY2026 10-K','Income p51; balance p53; cash flows p55; PP&E note p68; MD&A Item 7'],[link('Q27'),'Q2 FY2027 earnings release August 26 2026','Income, balance sheet, cash flows and outlook'],[link('Provider'),'Stock Analysis annual cash flow statement','Capital Expenditures annual field, retrieved September 24 2026']]),
              '## Reproduce',
              'Run `python3 nvidia_proforma.py` from this folder. The script recalculates the model, checks the accounting identities and regenerates this Markdown document. The original ABG script and earlier NVIDIA report remain available as references.']
    return '\n\n'.join(parts)+'\n'


if __name__ == '__main__':
    projections = project()
    output = ROOT / 'NVIDIA - Five Year Pro Forma - Sep 24.md'
    output.write_text(report(projections), encoding='utf-8')
    result = value(projections)
    print(f'Wrote {output}')
    print(f'All five years pass accounting checks; value ${result["per_share"]:.2f}/share')
