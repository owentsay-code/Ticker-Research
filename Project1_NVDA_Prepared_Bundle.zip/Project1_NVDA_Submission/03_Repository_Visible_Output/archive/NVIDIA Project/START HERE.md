# NVIDIA project — start here

## DCF Models and Research

- **NVIDIA - Five Year Pro Forma - Sep 24.md** — three years of sourced history and ratios, labeled assumptions, four linked projected statements, FCFE/FCFF, valuation, and unresolved items.
- **nvidia_proforma.py** — regenerates the September 24 pro forma and checks the accounting identities. Run `python3 nvidia_proforma.py` from the DCF Models and Research folder.
- **dcf.py** — training DCF, sensitivity grid, and reverse DCF. Target: $30.00. Run `python3 dcf.py` from that folder.
- **TRAINING - Inputs and Results.md** — saved training inputs and results, including the +1.78 percentage-point shift.
- **nvidia_company_model.py** — separate NVIDIA company model from September 8.
- **NVIDIA - Full Valuation Report - Sep 08.md** — company valuation assumptions and report.
- **NVIDIA - Quick Summary and Price - Sep 08.md** — company forecast table and saved September 8 price.
- **NVIDIA - Earlier Research Report - Sep 03.md** — earlier research report.
- **REFERENCE - Research Sources.md** — research sources.
- **HELP - How to Run Python.md** — Python environment instructions.

The training case remains labeled training because the starting FCFF and FCFF growth inputs for the simple company DCF are unresolved.

## Other folders

- **Working Files** — currently empty; space for drafts.
- **Exports** — currently empty; space for exported results.

Course instructions and frozen references remain in their existing files.

`dcf.py` keeps its assignment-required name: it is the TRAINING script. `nvidia_company_model.py` is the NVIDIA company script.
