# NVIDIA — visible model output

Historical valuation September 8, 2026; packaged October 19. No execution required to inspect these results. Full unrounded inputs/checks/scenarios are in Project1_NVDA_Results.json.

| Scenario | Causal assumptions | Year 5 EBIT ($bn) | Year 5 FCFF ($bn) | Value/share |
| --- | --- | --- | --- | --- |
| Low | Growth -5pp; EBIT margin -5pp; WACC 11%; g 2.5% | 373.24 | 290.41 | $125.30 |
| Base | Saved growth/margins; WACC 10%; g 3.5% | 502.82 | 385.97 | $209.28 |
| High | Growth +5pp; EBIT margin +5pp; WACC 9%; g 4.5% | 666.74 | 506.73 | $386.04 |

## Base Income statement

| USD bn | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
| --- | --- | --- | --- | --- | --- |
| revenue | 439.306 | 571.098 | 685.318 | 788.116 | 866.927 |
| cogs | 114.220 | 154.197 | 191.889 | 228.554 | 260.078 |
| gross | 325.087 | 416.902 | 493.429 | 559.562 | 606.849 |
| sga | 9.753 | 12.507 | 14.803 | 16.787 | 18.205 |
| rd | 34.178 | 50.314 | 67.435 | 77.787 | 85.826 |
| ebit | 281.156 | 354.081 | 411.191 | 464.988 | 502.818 |
| interest | 1.335 | 1.335 | 1.335 | 1.335 | 1.335 |
| pretax | 279.822 | 352.746 | 409.856 | 463.654 | 501.483 |
| tax | 47.570 | 59.967 | 69.676 | 78.821 | 85.252 |
| ni | 232.252 | 292.780 | 340.181 | 384.833 | 416.231 |

## Base Balance sheet

| USD bn | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
| --- | --- | --- | --- | --- | --- |
| cash | 195.235 | 427.091 | 707.807 | 1,033.609 | 1,394.188 |
| securities | 76.926 | 76.926 | 76.926 | 76.926 | 76.926 |
| ar | 93.750 | 123.419 | 149.131 | 172.272 | 190.014 |
| inventory | 46.943 | 61.798 | 74.673 | 86.260 | 95.144 |
| prepaid | 5.068 | 6.672 | 8.062 | 9.313 | 10.272 |
| ppe | 22.983 | 34.291 | 47.806 | 61.992 | 77.597 |
| intangibles | 2.207 | 1.179 | 0.000 | 0.000 | 0.000 |
| other_assets | 105.577 | 105.577 | 105.577 | 105.577 | 105.577 |
| assets | 548.690 | 836.954 | 1,169.983 | 1,545.950 | 1,949.718 |
| ap | 22.388 | 29.473 | 35.614 | 41.140 | 45.377 |
| accrued | 40.082 | 52.766 | 63.759 | 73.653 | 81.238 |
| debt | 33.366 | 33.366 | 33.366 | 33.366 | 33.366 |
| other_liabilities | 15.903 | 15.903 | 15.903 | 15.903 | 15.903 |
| liabilities | 111.739 | 131.508 | 148.642 | 164.062 | 175.884 |
| equity | 436.951 | 705.445 | 1,021.341 | 1,381.889 | 1,773.835 |

## Base Cash flow

| USD bn | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
| --- | --- | --- | --- | --- | --- |
| ni | 232.252 | 292.780 | 340.181 | 384.833 | 416.231 |
| da | 5.272 | 6.853 | 8.224 | 9.457 | 10.403 |
| sbc | 9.665 | 12.564 | 15.077 | 17.339 | 19.072 |
| delta_nwc | 27.267 | 26.358 | 22.844 | 20.560 | 15.762 |
| cfo | 219.921 | 285.838 | 340.638 | 391.069 | 429.944 |
| cfi | -13.179 | -17.133 | -20.560 | -23.643 | -26.008 |
| buybacks | 9.665 | 12.564 | 15.077 | 17.339 | 19.072 |
| dividends | 24.285 | 24.285 | 24.285 | 24.285 | 24.285 |
| cff | -33.950 | -36.849 | -39.362 | -41.624 | -43.357 |
| cash_change | 172.792 | 231.856 | 280.716 | 325.802 | 360.579 |
| opening_cash | 22.443 | 195.235 | 427.091 | 707.807 | 1,033.609 |
| cash | 195.235 | 427.091 | 707.807 | 1,033.609 | 1,394.188 |
| fcff | 198.185 | 257.249 | 306.109 | 351.195 | 385.972 |

Expense and investment rows are positive deductions unless explicitly signed cash flow fields. CFO/CFI/CFF retain signs. The engine keeps all unrounded amounts.

## Base DCF bridge

| Output | Value |
| --- | --- |
| explicit | 1,102.283477 |
| terminal_fcff | 409.726383 |
| terminal | 6,303.482817 |
| pv_terminal | 3,913.966891 |
| ev | 5,016.250368 |
| bridge | 66.003000 |
| equity | 5,082.253368 |
| per_share | 209.275411 |
| terminal_share | 0.780257 |

## WACC / terminal growth

| WACC | g 2.5% | g 3.5% | g 4.5% |
| --- | --- | --- | --- |
| 9% | $217.19 | $248.80 | $294.46 |
| 10% | $187.01 | $209.28 | $239.64 |
| 11% | $163.98 | $180.34 | $201.74 |

## One-at-a-time spans

| Driver | Low | Base | High | Signed EBIT span | Signed FCFF span | Signed value span |
| --- | --- | --- | --- | --- | --- | --- |
| Growth path shift (percentage points) | -5 | 0 | 5 | 205.365 | 143.178 | 75.557 |
| EBIT margin path shift (percentage points) | -5 | 0 | 5 | 86.693 | 71.955 | 37.712 |
| Operating tax (%) | 16 | 17 | 20 | 0.000 | -20.113 | -10.638 |
| Capital spending / sales (%) | 2 | 3 | 5 | 0.000 | -26.008 | -13.631 |
| Incremental working capital / incremental sales (%) | 15 | 20 | 30 | 0.000 | -11.822 | -4.495 |
| WACC (%) | 9 | 10 | 11 | 0.000 | 0.000 | -68.457 |
| Terminal growth (%) | 2.5 | 3.5 | 4.5 | 0.000 | 0.000 | 52.632 |

Spans are output at higher input minus output at lower input. Negative spans indicate a higher cost reduces output; importance uses absolute magnitude.

## Range dependence

| Growth ±pp | Margin ±pp | Growth EBIT/FCFF/value spans | Margin EBIT/FCFF/value spans |
| --- | --- | --- | --- |
| 5 | 5 | 205.365 / 143.178 / 75.557 | 86.693 / 71.955 / 37.712 |
| 1 | 5 | 40.944 / 28.562 / 15.067 | 86.693 / 71.955 / 37.712 |
| 5 | 1 | 205.365 / 143.178 / 75.557 | 17.339 / 14.391 / 7.542 |

Reverse constant annual revenue growth at the historical $225.73 quote: 26.257975%.

## Base checks

| Year | Check | Residual or balance ($bn) | Result |
| --- | --- | --- | --- |
| 0 | Opening balance sheet gap | -0.000000000000 | PASS |
| 1 | Balance sheet gap | -0.000000000000 | PASS |
| 1 | Cash reconciliation gap | -0.000000000000 | PASS |
| 1 | Equity rollforward gap | -0.000000000000 | PASS |
| 1 | Fixed asset rollforward gap | -0.000000000000 | PASS |
| 1 | Working capital gap | -0.000000000000 | PASS |
| 1 | Income statement gap | 0.000000000000 | PASS |
| 1 | FCFF formula gap | 0.000000000000 | PASS |
| 1 | FCFE to FCFF bridge gap | 0.000000000000 | PASS |
| 1 | cash nonnegative | 195.235044600000 | PASS |
| 1 | ppe nonnegative | 22.983268700000 | PASS |
| 1 | intangibles nonnegative | 2.207248300000 | PASS |
| 1 | rd nonnegative | 34.178045700000 | PASS |
| 2 | Balance sheet gap | -0.000000000000 | PASS |
| 2 | Cash reconciliation gap | 0.000000000000 | PASS |
| 2 | Equity rollforward gap | 0.000000000000 | PASS |
| 2 | Fixed asset rollforward gap | -0.000000000000 | PASS |
| 2 | Working capital gap | 0.000000000000 | PASS |
| 2 | Income statement gap | 0.000000000000 | PASS |
| 2 | FCFF formula gap | 0.000000000000 | PASS |
| 2 | FCFE to FCFF bridge gap | 0.000000000000 | PASS |
| 2 | cash nonnegative | 427.091393670000 | PASS |
| 2 | ppe nonnegative | 34.291018010000 | PASS |
| 2 | intangibles nonnegative | 1.179271090000 | PASS |
| 2 | rd nonnegative | 50.313773445000 | PASS |
| 3 | Balance sheet gap | -0.000000000000 | PASS |
| 3 | Cash reconciliation gap | -0.000000000000 | PASS |
| 3 | Equity rollforward gap | 0.000000000000 | PASS |
| 3 | Fixed asset rollforward gap | 0.000000000000 | PASS |
| 3 | Working capital gap | 0.000000000000 | PASS |
| 3 | Income statement gap | 0.000000000000 | PASS |
| 3 | FCFF formula gap | 0.000000000000 | PASS |
| 3 | FCFE to FCFF bridge gap | 0.000000000000 | PASS |
| 3 | cash nonnegative | 707.807411670000 | PASS |
| 3 | ppe nonnegative | 47.806015620000 | PASS |
| 3 | intangibles nonnegative | 0.000000000000 | PASS |
| 3 | rd nonnegative | 67.435304976000 | PASS |
| 4 | Balance sheet gap | -0.000000000000 | PASS |
| 4 | Cash reconciliation gap | -0.000000000000 | PASS |
| 4 | Equity rollforward gap | 0.000000000000 | PASS |
| 4 | Fixed asset rollforward gap | 0.000000000000 | PASS |
| 4 | Working capital gap | -0.000000000000 | PASS |
| 4 | Income statement gap | 0.000000000000 | PASS |
| 4 | FCFF formula gap | 0.000000000000 | PASS |
| 4 | FCFE to FCFF bridge gap | 0.000000000000 | PASS |
| 4 | cash nonnegative | 1033.609367903700 | PASS |
| 4 | ppe nonnegative | 61.992101118000 | PASS |
| 4 | intangibles nonnegative | 0.000000000000 | PASS |
| 4 | rd nonnegative | 77.787035480700 | PASS |
| 5 | Balance sheet gap | 0.000000000000 | PASS |
| 5 | Cash reconciliation gap | 0.000000000000 | PASS |
| 5 | Equity rollforward gap | -0.000000000000 | PASS |
| 5 | Fixed asset rollforward gap | -0.000000000000 | PASS |
| 5 | Working capital gap | -0.000000000000 | PASS |
| 5 | Income statement gap | 0.000000000000 | PASS |
| 5 | FCFF formula gap | 0.000000000000 | PASS |
| 5 | FCFE to FCFF bridge gap | 0.000000000000 | PASS |
| 5 | cash nonnegative | 1394.188478469840 | PASS |
| 5 | ppe nonnegative | 77.596795165800 | PASS |
| 5 | intangibles nonnegative | 0.000000000000 | PASS |
| 5 | rd nonnegative | 85.825817262900 | PASS |
