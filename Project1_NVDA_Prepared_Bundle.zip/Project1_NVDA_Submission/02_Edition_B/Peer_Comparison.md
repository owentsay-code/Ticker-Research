# Qualified annual peer comparison

Policy in Peer_Policy.txt was recorded before these new calculations on October 19, 2026. Historical comparison date: September 8, 2026. Existing September files did not establish a prior peer policy; this is a disclosed re-validation.

AMD qualifies for GPU/data-center overlap, with CPU and embedded differences. Broadcom qualifies for AI custom silicon/networking overlap, with material software differences. Reject direct multiple transfer without adjusting for profitability, growth, accounting and risk. No qualified transaction evidence is used.

All amounts USD billions except prices, EPS and multiples. Use the latest annual financial periods in the table, not TTM or forward values. Annual diluted weighted-average shares are a consistently applied lagged capitalization proxy, not actual September 8 market capitalization. Financial claims and asset exclusions still need a complete fair-value review.

| Name | Annual end | Price | Revenue | GAAP EPS | Diluted shares | Cash | Liquid securities | Debt | EV proxy | EV/revenue | P/E |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| NVDA | 2026-01-25 | 225.73 | 215.938 | 4.9 | 24.514 | 10.605 | 51.951 | 8.468 | 5479.457 | 25.38x | 46.07x |
| AMD | 2025-12-27 | 505.74 | 34.639 | 2.65 | 1.636 | 5.539 | 5.013 | 3.222 | 820.061 | 23.67x | 190.85x |
| AVGO | 2025-11-02 | 368.56 | 63.887 | 4.77 | 4.853 | 16.178 | 0 | 65.136 | 1837.580 | 28.76x | 77.27x |

EV proxy = price × annual diluted shares + annual debt - annual cash - separately identified liquid securities. P/E = price / total annual GAAP diluted EPS; it gets no cash/debt adjustment. Operating leases remain within operations. Broadcom has no separately identified liquid-securities line included here; zero means no separately included deduction, not proof that no financial investments exist. NVIDIA annual securities 51.951 differs intentionally from the later DCF bridge's 76.926. AMD debt = 0.874 + 2.348; Broadcom debt = 3.152 + 61.984.

AMD's $2.65 EPS includes $0.04 discontinued operations; $2.61 is continuing EPS. We retain total GAAP EPS consistently and flag the difference. Applying the peer P/E endpoints to NVDA $4.90 EPS gives $378.60–$935.14; the two-peer midpoint is $656.87. Remove either peer and the midpoint shifts by about $278.27. That instability and accounting/mix differences prevent its adoption as fair value.

The peer EV/revenue measures are about 23.67x–28.76x versus NVIDIA 25.38x. Similar sales multiples can coexist with widely different earnings multiples because margins and earnings adjustments differ. This is evidence to investigate, not proof that NVDA deserves either peer multiple. No average with DCF is computed.

Source lineage: [NVDA annual](https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/nvda-20260125.htm), income/balance/share note; [AMD annual](https://ir.amd.com/financial-information/sec-filings/content/0000002488-26-000018/amd-20251227.htm), income/balance statements; [AVGO annual](https://www.sec.gov/Archives/edgar/data/1730168/000173016825000121/avgo-20251102.htm), income/balance statements. Same-day Close sources are linked in Evidence_Ledger.md, all rechecked October 19. `app/peer_comparison.py` reproduces this table. Formula and denominator checks are in the validation record.
