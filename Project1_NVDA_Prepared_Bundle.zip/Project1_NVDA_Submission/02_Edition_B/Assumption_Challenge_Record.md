# Assumption-challenge record

Every row is an analyst judgment except identified filing inputs. Editable bounds are deliberate scenario limits, not statistical intervals; fixed quantities remain reviewable assumptions in this record. Independent judgments require student review before submission.

| Driver | Value / bounded range | Basis | Challenge | Evidence that changes it |
| --- | --- | --- | --- | --- |
| Revenue growth | 45/30/20/15/10%; ±5pp | Demand deceleration; first-year sales 439.3 vs quarter outlook annualized 432, a rough scale check only | Customer funding/capex delays; no units/ASP build | Order cancellations, deployment delays or customer spending guidance |
| EBIT margin | 64/62/60/59/58%; ±5pp | Platform profitability fading with competition; TTM operating margin about 65.2% | 58% in perpetuity may overstate durability | Pricing, product mix, gross margin and operating-cost evidence |
| Tax | 17%; panel 16–20% | Midpoint of 16–18% guidance; upper bound an adverse tax scenario | Cash operating tax differs from GAAP effective rate | Jurisdiction mix, discrete items, tax law and cash taxes |
| Capex / sales | 3%; panel 2–5% | FY26 purchases about 2.8% of sales; future infrastructure needs may rise | Fabless does not mean zero owned infrastructure | Capital commitments and recurring cash purchases |
| D&A / sales | 1.2%; fixed | Approximate history; FY26 D&A around 1.3% | May diverge from capex and asset lives | PP&E rollforward and depreciation notes |
| Incremental NWC | 20%; panel 15–30% | Opening NWC / TTM sales about 18.5%; marginal ratio is judgment | Marginal needs need not equal historical stock ratio | Receivable/inventory days, payment terms, customer financing |
| WACC | 10%; panel 9–11% | Required-return judgment, not estimated CAPM | Concentration and cyclicality may justify higher return | Dated risk-free rate, beta, ERP and debt spreads |
| Terminal growth | 3.5%; panel 2.5–4.5% | Long-run nominal scenario, less than all allowed WACCs | Upper range may outgrow mature addressable markets | Long-run spending, competition and returns on capital |
| Gross margin / SG&A | 74→70%; SG&A 3% of gross profit; fixed | Condensed economics; R&D is residual | Can mask underinvestment; 85% EBIT fails negative R&D | Cost detail and required research spending |
| SBC / shares | SBC 2.2% sales; buybacks offset; shares 24.285bn fixed | Economic cost retained in FCFF; avoids free dilution assumption | Dollar repurchases may not actually offset awarded shares | Award count, repurchase prices and share rollforward |
| Debt / interest | 33.366bn fixed; 4% interest; no net borrowing | Simple financing; debt book value approximates fair value | Does not model maturities or credit spread changes | Maturity schedule, refinancing terms and revolver needs |
| Dividends | 24.285bn annually; fixed | Saved $1 per proxy share distribution assumption | Distribution policy can change; does not determine FCFF | Board declarations and liquidity |
| Other balance-sheet items | Securities, other assets/liabilities fixed; OCI/investment income zero | Isolate operating model; excess cash accumulates without yield | Acquisitions, tax balances and fair-value changes omitted | New investments, disposals, taxes and acquisitions |
| Equity bridge | 66.003bn net assets; fixed | Opening cash + liquid securities - debt | Availability, taxes and omitted claims may reduce bridge | Liquidity restrictions, sale taxes, noncontrolling/preferred claims |

## Fresh-eyes credit and revision

Existing lab evidence attributes “What if the AI bubble pops?” to the student's human partner, whose name is not supplied. Credit: human lab partner, identity pending student confirmation. The later example approval is reported by the student, not an independently observed audit. The earlier locked-prediction role explicitly credited an AI assistant as Partner; preserve that distinction.

Accepted challenge: durable use of AI does not guarantee durable infrastructure spending. Revision: retain watch/defer, make demand and customer financing explicit monitoring triggers, add combined adverse cases and report that these cases still do not represent a full spending collapse. Additional AI-assisted challenge: the original sensitivity narrative said ranking could reverse without testing it; the new narrower-growth experiment now demonstrates the reversal.

The live checks panel also flags EBIT margins outside the disclosed 54.12–66.24% historical reference band (FY24–FY26 and latest quarter). A red historical-band alert is distinct from accounting INVALID: the scenario remains calculable, but extrapolation needs explicit defense. The 85% diagnostic fails accounting feasibility and withholds valuation.
