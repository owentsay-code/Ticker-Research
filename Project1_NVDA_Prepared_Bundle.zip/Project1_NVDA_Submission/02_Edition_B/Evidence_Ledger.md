# Evidence, transformations and normalization

Historical cutoff: September 8, 2026. Source recheck: October 19, 2026. Financial data are USD billions after dividing filing USD millions by 1,000. This is a data-extraction ledger; full original prose/filings are linked, not republished. Public financial sources; no credentials or personal financial data are embedded. Keep provider attribution; do not assume permission to redistribute full proprietary feeds.

| ID | Source / locator | Period and date | Use |
| --- | --- | --- | --- |
| K26 | [NVIDIA 10-K](https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/nvda-20260125.htm), income p51, balance p53, cash p55, debt note | FY ended Jan 25 2026; filed Feb 25 2026 | Annual starting values, normalization and target peer denominator |
| Q27 | [NVIDIA Q2 release](https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Announces-Financial-Results-for-Second-Quarter-Fiscal-2027/default.aspx), condensed income/balance/cash and outlook | July 26 2026; released Aug 26 2026 | TTM construction, opening accounts, diluted share proxy, tax guidance |
| AMD | [AMD 10-K](https://ir.amd.com/financial-information/sec-filings/content/0000002488-26-000018/amd-20251227.htm), statements pp58–63 | Dec 27 2025; filed Feb 4 2026 | Annual peer definitions and amounts |
| AVGO | [Broadcom 10-K](https://www.sec.gov/Archives/edgar/data/1730168/000173016825000121/avgo-20251102.htm), statements pp47–50 | Nov 2 2025; filed Dec 2025 | Annual peer definitions and amounts |
| Prices | [NVDA](https://stockanalysis.com/stocks/nvda/history/), [AMD](https://stockanalysis.com/stocks/amd/history/), [AVGO](https://stockanalysis.com/stocks/avgo/history/) daily historical Close column | Sep 8 2026 close; rechecked Oct 19 | $225.73 / $505.74 / $368.56; split-adjusted Close, not dividend-adjusted close |

## Filing-to-base mapping

TTM revenue = 215.938 + 177.837 - 90.805 = **302.970**. TTM cost of sales = 62.475 + 44.538 - 30.284 = **76.729**; gross profit **226.241**. TTM operating expenses = 23.076 + 16.029 - 10.443 = **28.662**; EBIT = 130.387 + 117.270 - 50.078 = **197.579**. The forecast does not extrapolate GAAP net income including investment gains. At the judgmental 17% operating tax, normalized operating NOPAT proxy is **163.991**. This is an analytical operating base, not reported net income.

Opening July balance sheet mapping (Q27): cash 22.443; securities 34.143 + 42.783 = 76.926; receivables 63.059; inventory 31.575; prepaids 3.409; PP&E 14.285; intangibles 2.998. Other assets = 5.390 lease assets + 21.125 goodwill + 12.159 deferred tax assets + 51.157 nonmarketable securities + 15.746 other = 105.577. Payables 15.059; accrued 26.960; debt 1.000 + 32.366 = 33.366; other liabilities 4.985 leases + 10.918 other = 15.903; equity 228.984. Assets and liabilities/equity each total **320.272**. NWC = AR + inventory + prepaids - AP - accrued = **56.024**.

Historical six-month cash check: opening 10.605 + CFO 74.421 - CFI 35.124 - CFF 27.459 = **22.443**. Quarterly diluted shares **24.285** differ from basic **24.190** and six-month diluted **24.338**. The model intentionally uses quarterly diluted weighted-average as a proxy, not actual spot shares; sensitivity to dilution remains a limitation. These mapped amounts are executable checks in validate.py.

## Contamination catalog and normalized base

| Item | Treatment | Why / evidence that changes it |
| --- | --- | --- |
| FY26 H20 charge $4.5bn in first half FY26 | Annual EBIT 130.387 + 4.5 = 134.887 if isolating that charge only; not a fully normalized earnings claim | K26 risk/MD&A; future export costs may recur |
| Mixing annual and half-year charge adjustments | Do not add $4.5bn again to TTM EBIT: the affected H1 FY26 is already subtracted in the TTM construction | Prevent double normalization; review later reversals/charges before any further adjustment |
| Investment gains and financing income | Begin with operating EBIT and an operating tax proxy; forecast investment returns zero | Separate operating cash generation from portfolio marks; securities handled in bridge |
| SBC definition change | Keep SBC in GAAP operating costs; Q27 says FY27 non-GAAP now includes SBC and recasts history | Do not splice unrecast historical adjusted margins with new adjusted margins |
| Cash flow provider “FCF” | Company FCF subtracts capital purchases and related principal payments from CFO; model FCFF is unlevered NOPAT plus D&A less reinvestment | These labels are not interchangeable; this primary-source definition check qualifies prior AI shorthand |
| Timing | FY26 + H1 FY27 - H1 FY26 income base; July balance sheet proxy; Sep 8 price | Explicit lag, no unstated stub or Oct data refresh |
| Share basis | DCF uses latest-quarter diluted proxy; annual peer table uses annual diluted proxy for all names | Different purposes are labeled; do not mix the two tables |
| Liquid assets / claims | Securities at carrying value; no disposal taxes; nonmarketable investments excluded from EV bridge | A realizable-value/tax/claims assessment could move equity value |
| Recurring costs | No blanket addback for SBC, recurring R&D or ordinary inventory expense | Future operating costs remain economic costs |

The TTM construction removes the identified old H20 period and excludes investment income by using EBIT, but is not a full forensic restatement of all unusual items. Deferred taxes, acquisition effects and any charge reversals need further review before claiming fully normalized GAAP statements. Forecast margins are explicit judgments anchored to this base, not mechanically generated historical truth.

## Independent source/definition check and AI disposition

**QUALIFY** the saved AI-assisted output “base value $209.28.” The engine reproduces it, and source mapping agrees, but it is conditional on a share proxy, assumed WACC and terminal margin. **REJECT** any implication that balanced statements alone validate the thesis. Independently opened Q27 distinguishes company FCF from FCFF and quarterly diluted from basic shares; those checks support the chosen labels, not the forecast's probability. The original record is archived and the qualified conclusion is reflected in WATCH/DEFER.
