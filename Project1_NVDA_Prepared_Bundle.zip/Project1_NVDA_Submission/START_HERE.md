# Your Project 1 submission

You have most of the analytical foundation. This folder organizes it and adds the missing workbench, consolidated analysis, memo, visible outputs and technical validation. **This is a prepared package with remaining human/course evidence gaps, not a claim that every requirement is complete.** Nothing has been uploaded to Brightspace.

## What to submit

The assignment says seven parts, but its shared checklist was not supplied. The folders below are a practical provisional grouping, not verified official filenames. The rubric does not supply the filenames or video durations. Confirm these against the shared checklist before uploading.

| Part | What belongs in it | Prepared here | Still needed |
| --- | --- | --- | --- |
| 1 | Original, unchanged Edition A | 01_Edition_A/Project1_EditionA_NVDA.md, original hash verified | First successful Brightspace checkpoint receipt |
| 2 | Edition B showing research/decision evolution | 02_Edition_B/Project1_EditionB_NVDA.html and .md, assumptions and evidence | Read and take ownership of judgments; reconcile any instructor template |
| 3 | Runnable repository plus outputs visible without running | 03_Repository_Visible_Output, local app, full JSON and HTML output | Check course repository/link rule; test on your own computer |
| 4 | Research-evolution Video 1 + corrected transcript | 04_Video_1/Recording_Guide.md | Record actual video; correct its actual transcript |
| 5 | Code/validation Video 2 + corrected transcript | 05_Video_2/Recording_Guide.md | Record code defense and clean run; correct actual transcript |
| 6 | Memo/deck and committee Video 3 + corrected transcript | 06_Committee_Memo_Video_3/Project1_NVDA_Committee_Memo.html and .md, demo guide | Record live product opening and defense; correct actual transcript |
| 7 | Frozen validation/AI-use record and manifest | 07_Validation_AI_Record; file hashes | Human AI-off evidence, course benchmark, final access/receipt checks |

If the shared checklist counts the memo and Video 3 as separate parts and groups A/B together, regroup the same files. Do not omit anything to force our provisional folder numbering.

## Your remaining tasks, in priority order

1. Locate the original Edition A Brightspace receipt. A matching local hash proves file identity, not timely checkpoint submission.
2. Locate a genuinely human-authored, AI-off prediction saved before its run. The September record explicitly includes an assistant acting as Partner; AI-off authorship is unproven. Do not simply sign that AI-generated text as your own. If no qualifying record exists, follow the instructor's remediation process for a new prospective experiment. A blank form is provided; do not backdate it. Do not use an already-revealed run as an unseen prediction.
3. Obtain the weekly starter's published training-case answers. The independent Decimal reconciliation passes, but a direct match to the course answer sheet is still unverified.
4. Supply your human lab partner's name if credit is required. The archive preserves the reported challenge (“What if the AI bubble pops?”), but does not establish their identity. Do not credit the assistant as a human partner.
5. Read Edition B, the memo and assumptions. WACC and terminal economics remain consequential judgments; the draft retains WATCH/DEFER. Approve or revise those judgments yourself before defending them.
6. Record three separate videos using the guides. Video 3 must begin with a live working demonstration: change a bounded driver, explain versus restored base, show failure, recover. Record a clean run for Video 2. Confirm the official time limits first.
7. Generate transcripts from your actual recordings, then correct numbers, names, units and speaker wording. Recording guides are not transcripts. Add the media and transcripts, update the manifest with `python3 freeze_manifest.py`, and rebuild the ZIP with `python3 package_zip.py` from this folder.
8. Confirm official filenames, due date, required upload/link format, video access permissions, and final Brightspace receipt. The due date is only in Brightspace; it cannot be inferred from this rubric.

## Open the product

In Terminal:

```bash
cd "/Users/owentsay/Documents/Codex/Project1_NVDA_Submission/03_Repository_Visible_Output/app"
python3 workbench.py
```

Open http://127.0.0.1:8765 in a browser. Keep Terminal running; Ctrl+C stops it. Python 3.10+ and a browser are the only requirements. No pip packages, login, credentials, hosting or network data feed is needed. If the port is busy, run `python3 workbench.py --port 8766` and open that port instead. Do not double-click interface.html: it requires the local Python engine.

For a grader who does not run code, open `03_Repository_Visible_Output/Project1_NVDA_Visible_Output.html`. HTML documents open directly and can be printed or saved as PDF from a browser if the course accepts PDF. Markdown versions remain editable.

The financial analysis uses September 8, 2026 as its historical valuation date; package preparation and source rechecks occurred October 19. It is not an October 19 price recommendation. The older September 24 pro-forma convention is preserved in the archive; Edition B explicitly adopts one September 8 rolling-year convention.
