"""Freeze hashes for the current package. No upload or historical attestation."""
from pathlib import Path
import hashlib,json,datetime
R=Path(__file__).resolve().parent
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or any(v in p.parts for v in ('.venv','__pycache__','.git')) or p.name in ('MANIFEST.json','.DS_Store'):continue
 files.append(dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
x=dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='Prepared package; human/course evidence still required',official_filenames_verified=False,files=files,
 missing=['Edition A Brightspace receipt','Qualifying human-authored AI-off precommit evidence','Published course training-answer comparison','Human challenger identity if required','Three videos and corrected actual transcripts','Student recorded cold run','Official checklist and final submission receipt'])
(R/'MANIFEST.json').write_text(json.dumps(x,indent=2)+'\n')
print('Manifest:',len(files),'files. This is a current integrity snapshot, not proof of past timing.')
