"""Package exactly the files in the current manifest, after verifying their hashes."""
from pathlib import Path
import zipfile,json,hashlib
R=Path(__file__).resolve().parent
manifest=json.loads((R/'MANIFEST.json').read_text())
for row in manifest['files']:
 p=R/row['path']
 if hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:raise SystemExit('Manifest out of date. Run python3 freeze_manifest.py first: '+row['path'])
output=R.parent/'Project1_NVDA_Prepared_Bundle.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
 for row in manifest['files']:z.write(R/row['path'],R.name+'/'+row['path'])
 z.write(R/'MANIFEST.json',R.name+'/MANIFEST.json')
with zipfile.ZipFile(output) as z:
 assert z.testzip() is None
print(output)
