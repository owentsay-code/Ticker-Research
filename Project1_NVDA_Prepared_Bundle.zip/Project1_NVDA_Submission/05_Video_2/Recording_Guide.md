# Video 2 — Code ownership and validation

AI-assisted preparation guide, not a transcript. Official duration and filename rules still need confirmation.

1. State the purpose and map the data flow: saved inputs → linked accounting engine → isolated runs → DCF/bridge → bounded interface. Show the README.
2. Trace one year's FCFF from revenue, EBIT, tax, D&A, capex and working capital. Explain why dividends are a use of equity cash and why accumulated forecast cash is not added again to EV.
3. Show `python3 -B validate.py` and explain representative tests: independent Decimal training answer; source-to-opening mapping; balance/cash rollforwards; WACC/g monotonicity; EV/equity bridge; invalid margin failure. Numerical PASS is not proof of economic assumptions.
4. Show the human-authored AI-off locked record only if you have genuine evidence. Identify its precommit, old/new units, predicted direction and decision effect, actual result and diagnosis. The existing AI-assisted September record alone is insufficient; do not present it as an AI-off human prediction.
5. Show the executed range-ranking reversal. With growth ±1pp and margin ±5pp, margin overtakes growth for EBIT, FCFF and value.
6. Record a clean run: from the package root run `python3 07_Validation_AI_Record/cold_run.py`. It creates a new temporary virtual environment without pip or third-party packages, copies the app, runs tests/exports and checks exact agreement. Then start the app from the fresh directory printed by that command (its `venv/bin/python` and `03_Repository_Visible_Output/app/workbench.py`) using an unused port, and demonstrate it in a browser. Keep the full startup/run in the recording; do not imply an edited clip proves a clean environment.
7. Show the frozen manifest and distinguish completed numerical tests from outstanding course-specific proof. Explain one limitation, such as residual R&D, lagged share count or assumed WACC.

The prepared automated clean-run log is written evidence, not the required student's recorded cold run. The course's published starter answer sheet still must be compared with the synthetic answer. Add that comparison and its source when available.

Provisional video name: Project1_NVDA_Video2.mp4. Generate and correct Project1_NVDA_Video2_Transcript.txt from the actual recording. Do not copy these speaking prompts into a file and call it a transcript.
