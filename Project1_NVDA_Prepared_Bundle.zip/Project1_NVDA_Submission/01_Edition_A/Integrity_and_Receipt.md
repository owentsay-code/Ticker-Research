# Unchanged Edition A

Copied byte-for-byte from `/Users/owentsay/Downloads/Project1_EditionA_NVDA (1).md`.

SHA-256: `4b18ec766a5dca67486bf8ed139201e24a085f4110bc6735072378253fe2734d`

This matches the existing frozen-reference files in the original NVIDIA folder. No corrections were made to Edition A, including its provisional INITIATE conclusion or fiscal-year ambiguity. Those changes belong in Edition B.

First successful Brightspace receipt: **NOT FOUND / student must supply.** Neither the local hash, original file date nor this package establishes that receipt or verifies the original AI-use boundary.
